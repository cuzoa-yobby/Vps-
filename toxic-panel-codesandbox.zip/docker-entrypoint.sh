#!/bin/sh
# ============================================================
# Toxic Panel — Docker Entrypoint
# Seeds the admin user on first run, then starts the server
# ============================================================

set -e

echo "========================================="
echo "  Toxic Panel — Starting..."
echo "========================================="

# Create data directory if it doesn't exist
mkdir -p /app/data /app/uploads

# Check if database needs seeding
if [ ! -f /app/data/toxic.db ]; then
    echo "[Setup] First run detected — creating admin user..."
    node /app/seed.js
    echo "[Setup] Done!"
else
    echo "[Setup] Database exists, skipping seed."
fi

# Push any Prisma schema changes
echo "[Setup] Checking database schema..."
npx prisma db push --skip-generate 2>/dev/null || echo "[Setup] Schema check done (may need manual migration)"

echo ""
echo "  Toxic Panel is running!"
echo "  URL: http://localhost:3000"
echo "  Admin: toxic_admin / ToxicAdmin@2024"
echo "========================================="
echo ""

# Start the Next.js server
exec node server.js
