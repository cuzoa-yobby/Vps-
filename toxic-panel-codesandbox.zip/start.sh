#!/bin/bash
# ============================================================
# Toxic Panel — CodeSandbox / VPS Start Script
# Usage: chmod +x start.sh && ./start.sh
# ============================================================

set -e

echo "╔══════════════════════════════════════════╗"
echo "║     Toxic Panel — Starting...            ║"
echo "╚══════════════════════════════════════════╝"

# Check if node_modules exists
if [ ! -d "node_modules" ]; then
    echo "[1/4] Installing dependencies..."
    npm install
else
    echo "[1/4] Dependencies found, skipping install."
fi

# Generate Prisma client
echo "[2/4] Generating Prisma client..."
npx prisma generate

# Push database schema
echo "[3/4] Setting up database..."
export DATABASE_URL="file:./db/toxic.db"
mkdir -p db
npx prisma db push --skip-generate 2>/dev/null

# Seed admin user
echo "[3/4] Checking admin user..."
if [ ! -f "db/toxic.db" ]; then
    node seed.js
else
    # Check if admin exists
    ADMIN_CHECK=$(node -e "
        const { PrismaClient } = require('@prisma/client');
        const p = new PrismaClient();
        p.user.findUnique({ where: { username: 'toxic_admin' } })
            .then(u => { console.log(u ? 'EXISTS' : 'MISSING'); p.\$disconnect(); })
            .catch(() => { console.log('MISSING'); p.\$disconnect(); });
    " 2>/dev/null)
    if [ "$ADMIN_CHECK" = "MISSING" ]; then
        echo "  Creating admin user..."
        node seed.js
    else
        echo "  Admin user exists, skipping."
    fi
fi

# Build
echo "[4/4] Building panel..."
npm run build

echo ""
echo "╔══════════════════════════════════════════╗"
echo "║     Toxic Panel — Ready!                 ║"
echo "║     Admin: toxic_admin / ToxicAdmin@2024 ║"
echo "╚══════════════════════════════════════════╝"
echo ""

# Start server
NODE_ENV=production node .next/standalone/server.js
