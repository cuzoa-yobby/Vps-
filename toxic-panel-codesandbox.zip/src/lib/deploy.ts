import { spawn, execSync, ChildProcess } from 'child_process';
import os from 'os';
import fs from 'fs';
import path from 'path';

interface ProcessInfo {
  pid: number;
  status: 'running' | 'stopped' | 'error';
  logs: Array<{ text: string; type: 'normal' | 'warning' | 'error' | 'success' | 'info'; timestamp: number }>;
  workingDir: string;
  entryPoint: string;
  startTime: number;
  process: ChildProcess | null;
}

const processes = new Map<string, ProcessInfo>();

const ENTRY_POINTS = [
  'bot.js', 'main.js', 'index.js', 'server.js', 'app.js',
  'bot.py', 'main.py', 'app.py',
];

function classifyLog(text: string): 'normal' | 'warning' | 'error' | 'success' | 'info' {
  const lower = text.toLowerCase();
  if (lower.includes('error') || lower.includes('fail') || lower.includes('exception') || lower.includes('traceback') || lower.includes('syntaxerror') || lower.includes('cannot find module') || lower.includes('enoent') || lower.includes('eacces') || lower.includes('permission denied') || lower.includes('unhandledrejection') || lower.includes('uncaught exception') || lower.includes('typeerror') || lower.includes('referenceerror') || lower.includes('rangeerror') || lower.includes('segfault') || lower.includes('heap out of memory') || lower.includes('fatal error')) return 'error';
  if (lower.includes('warn') || lower.includes('deprecated') || lower.includes('caution') || lower.includes('experimental')) return 'warning';
  if (lower.includes('success') || lower.includes('ready') || lower.includes('connected') || lower.includes('listening') || lower.includes('started') || lower.includes('bot is ready') || lower.includes('logged in') || lower.includes('online')) return 'success';
  if (lower.includes('info') || lower.includes('[info]') || lower.includes('using') || lower.includes('serving') || lower.includes('[toxic]') || lower.includes('discord') || lower.includes('booting')) return 'info';
  return 'normal';
}

/** Check if a crash was likely caused by user code errors vs system errors */
function classifyExitError(exitCode: number | null, uptimeMs: number, recentLogs: Array<{ text: string; type: string }>): 'user_code' | 'system_error' | 'user_stop' | 'oom' | 'unknown' {
  // Exit code 0 = clean exit, likely user-initiated stop
  if (exitCode === 0) return 'user_stop';

  // Exit code 137 or -9 = SIGKILL (OOM killer or manual kill)
  if (exitCode === 137 || exitCode === -9) return 'oom';

  // Check for OOM indicators in recent logs
  const recentText = recentLogs.slice(-20).map(l => l.text.toLowerCase()).join('\n');
  if (recentText.includes('heap out of memory') || recentText.includes('out of memory') || recentText.includes('cannot allocate')) {
    return 'oom';
  }

  // Check for system-level error indicators
  if (recentText.includes('enoent') && !recentText.includes('node_modules')) {
    // ENOENT for non-module files could be system, but usually user code
  }
  if (recentText.includes('eacces') || recentText.includes('permission denied')) {
    return 'system_error';
  }

  // If crashed within the first 10 seconds, it's almost certainly a user code error
  if (uptimeMs < 10000) return 'user_code';

  // If there are error-type logs in the recent output, classify as user code
  const recentErrors = recentLogs.slice(-10).filter(l => l.type === 'error');
  if (recentErrors.length > 0) return 'user_code';

  // Non-zero exit with no obvious indicators
  return 'unknown';
}

/** Build a user-friendly error message based on crash classification */
function buildCrashMessage(classification: string, exitCode: number | null, uptimeMs: number): string {
  const uptimeStr = uptimeMs < 1000 ? `${uptimeMs}ms` : `${(uptimeMs / 1000).toFixed(1)}s`;

  switch (classification) {
    case 'user_code':
      return `[Toxic] ⚠ Your bot crashed on startup (${uptimeStr}). Check the error above — this is likely a bug in your code, not the hosting system.`;
    case 'system_error':
      return `[Toxic] ⚠ Process exited with code ${exitCode} — permission or system error detected. Check file permissions and paths.`;
    case 'oom':
      return `[Toxic] ⚠ Process was killed (code ${exitCode}) — likely ran out of memory. Try optimizing your bot or reducing memory usage.`;
    case 'user_stop':
      return `[Toxic] Process exited cleanly (code 0).`;
    case 'unknown':
      if (exitCode === 1) {
        return `[Toxic] ⚠ Process exited with code 1 — this usually indicates a runtime error. Check the logs above for details.`;
      }
      return `[Toxic] ⚠ Process exited unexpectedly with code ${exitCode}. Check the logs above for details.`;
    default:
      return `[Toxic] Process exited with code ${exitCode}`;
  }
}

export function findProjectRoot(dirPath: string): { root: string; entry: string } | null {
  // Check if there's an entry point at root level
  for (const ep of ENTRY_POINTS) {
    if (fs.existsSync(path.join(dirPath, ep))) {
      return { root: dirPath, entry: ep };
    }
  }

  // Check for nested structure (ZIP often has one top-level folder)
  try {
    const entries = fs.readdirSync(dirPath, { withFileTypes: true });
    const topDirs = entries.filter(e => e.isDirectory() && !e.name.startsWith('.'));

    if (topDirs.length === 1) {
      const subDir = path.join(dirPath, topDirs[0].name);
      for (const ep of ENTRY_POINTS) {
        if (fs.existsSync(path.join(subDir, ep))) {
          return { root: subDir, entry: ep };
        }
      }
      if (fs.existsSync(path.join(subDir, 'package.json'))) {
        return { root: subDir, entry: '' };
      }
    }

    // Check all subdirectories
    for (const dir of topDirs) {
      for (const ep of ENTRY_POINTS) {
        if (fs.existsSync(path.join(dirPath, dir.name, ep))) {
          return { root: path.join(dirPath, dir.name), entry: ep };
        }
      }
    }

    // Check for package.json main field in any subdirectory
    for (const dir of topDirs) {
      const pkgPath = path.join(dirPath, dir.name, 'package.json');
      if (fs.existsSync(pkgPath)) {
        try {
          const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));
          if (pkg.main) {
            return { root: path.join(dirPath, dir.name), entry: pkg.main };
          }
        } catch { /* ignore */ }
      }
    }
  } catch { /* ignore */ }

  return null;
}

export function deployBot(userId: string, workingDir: string, entryPoint?: string): { success: boolean; message: string; pid?: number } {
  // Stop existing process if running
  stopBot(userId);

  // Find project root and entry point
  const projInfo = findProjectRoot(workingDir);
  let actualRoot = workingDir;
  let entry = entryPoint;

  if (projInfo) {
    actualRoot = projInfo.root;
    if (!entry && projInfo.entry) {
      entry = projInfo.entry;
    }
  }

  if (!entry) {
    // Last resort: try top-level entries
    for (const ep of ENTRY_POINTS) {
      if (fs.existsSync(path.join(workingDir, ep))) {
        entry = ep;
        break;
      }
    }
  }

  if (!entry) {
    return { success: false, message: 'No entry point found. Expected: bot.js, main.js, index.js, server.js, app.js, bot.py, main.py, app.py' };
  }

  const fullPath = path.join(actualRoot, entry);
  if (!fs.existsSync(fullPath)) {
    // Try from workingDir directly
    const altPath = path.join(workingDir, entry);
    if (fs.existsSync(altPath)) {
      actualRoot = workingDir;
    } else {
      return { success: false, message: `Entry point not found: ${entry}` };
    }
  }

  const isPython = entry.endsWith('.py');
  const cmd = isPython ? 'python3' : 'node';

  // Run npm install / pip install in the actual root directory
  const pkgManager = isPython ? 'pip3' : 'npm';
  const installCmd = isPython ? ['install', '-r', 'requirements.txt'] : ['install', '--production'];

  try {
    if (!isPython && fs.existsSync(path.join(actualRoot, 'package.json'))) {
      runInstall(pkgManager, installCmd, { cwd: actualRoot, stdio: 'pipe' });
    } else if (isPython && fs.existsSync(path.join(actualRoot, 'requirements.txt'))) {
      runInstall(pkgManager, installCmd, { cwd: actualRoot, stdio: 'pipe' });
    }
    // Also try workingDir if actualRoot didn't have it
    if (actualRoot !== workingDir) {
      if (!isPython && fs.existsSync(path.join(workingDir, 'package.json'))) {
        runInstall(pkgManager, installCmd, { cwd: workingDir, stdio: 'pipe' });
      } else if (isPython && fs.existsSync(path.join(workingDir, 'requirements.txt'))) {
        runInstall(pkgManager, installCmd, { cwd: workingDir, stdio: 'pipe' });
      }
    }
  } catch (e) {
    // Continue even if install fails
  }

  let proc: ChildProcess;
  try {
    proc = spawn(cmd, [entry], {
      cwd: actualRoot,
      env: { ...process.env },
      stdio: ['pipe', 'pipe', 'pipe'],
    });
  } catch (e: any) {
    return { success: false, message: `Failed to spawn process: ${e.message}` };
  }

  const startTime = Date.now();
  const procInfo: ProcessInfo = {
    pid: proc.pid || 0,
    status: 'running',
    logs: [{ text: `[Toxic] Starting ${entry}...`, type: 'info', timestamp: startTime }],
    workingDir: actualRoot,
    entryPoint: entry,
    startTime,
    process: proc,
  };

  proc.stdout.on('data', (data: Buffer) => {
    const lines = data.toString().split('\n');
    for (const line of lines) {
      if (line.trim()) {
        procInfo.logs.push({ text: line, type: classifyLog(line), timestamp: Date.now() });
      }
    }
    // Keep max 500 logs
    if (procInfo.logs.length > 500) {
      procInfo.logs = procInfo.logs.slice(-400);
    }
  });

  proc.stderr.on('data', (data: Buffer) => {
    const lines = data.toString().split('\n');
    for (const line of lines) {
      if (line.trim()) {
        procInfo.logs.push({ text: line, type: classifyLog(line), timestamp: Date.now() });
      }
    }
    if (procInfo.logs.length > 500) {
      procInfo.logs = procInfo.logs.slice(-400);
    }
  });

  proc.on('close', (code) => {
    const uptimeMs = Date.now() - startTime;
    procInfo.status = 'stopped';
    procInfo.process = null;

    // Classify the crash type for better error messages
    if (code !== null && code !== 0) {
      const classification = classifyExitError(code, uptimeMs, procInfo.logs);
      const crashMessage = buildCrashMessage(classification, code, uptimeMs);

      procInfo.logs.push({
        text: crashMessage,
        type: 'error',
        timestamp: Date.now(),
      });

      // Add extra context for user code crashes
      if (classification === 'user_code' && uptimeMs < 10000) {
        procInfo.logs.push({
          text: `[Toxic] Common fixes: check for syntax errors, missing dependencies (run npm install), incorrect entry point, or typos in your code.`,
          type: 'info',
          timestamp: Date.now(),
        });
      }
    } else {
      procInfo.logs.push({
        text: `[Toxic] Process exited with code ${code}`,
        type: code === 0 ? 'success' : 'error',
        timestamp: Date.now(),
      });
    }
  });

  proc.on('error', (err) => {
    const uptimeMs = Date.now() - startTime;
    procInfo.status = 'error';
    procInfo.process = null;

    // Classify spawn errors for better UX
    const errMsg = err.message.toLowerCase();
    let userMessage = `[Toxic] Process error: ${err.message}`;

    if (errMsg.includes('enoent')) {
      userMessage = `[Toxic] ⚠ Failed to start process — the entry point or interpreter was not found. Make sure Node.js/Python is installed and the entry file exists.`;
    } else if (errMsg.includes('eacces') || errMsg.includes('permission')) {
      userMessage = `[Toxic] ⚠ Permission denied — the process does not have permission to execute. Check file permissions.`;
    } else if (errMsg.includes('spawn')) {
      userMessage = `[Toxic] ⚠ Failed to spawn process: ${err.message}. This may be a system issue — please try again or contact support.`;
    }

    procInfo.logs.push({
      text: userMessage,
      type: 'error',
      timestamp: Date.now(),
    });

    // Add helpful suggestion for ENOENT errors
    if (errMsg.includes('enoent')) {
      procInfo.logs.push({
        text: `[Toxic] Make sure the file '${entry}' exists in your project directory and the correct entry point is specified.`,
        type: 'info',
        timestamp: Date.now(),
      });
    }
  });

  processes.set(userId, procInfo);

  return { success: true, message: `Bot deployed successfully`, pid: proc.pid };
}

function runInstall(cmd: string, args: string[], options: any) {
  const proc = spawn(cmd, args, options);
  proc.stdout?.on('data', () => {});
  proc.stderr?.on('data', () => {});
  proc.on('close', () => {});
}

export function stopBot(userId: string): { success: boolean; message: string } {
  const procInfo = processes.get(userId);
  if (!procInfo || !procInfo.process) {
    return { success: false, message: 'No running process found' };
  }

  try {
    procInfo.process.kill('SIGTERM');
    setTimeout(() => {
      if (procInfo.process) {
        procInfo.process.kill('SIGKILL');
      }
    }, 5000);
  } catch (e: any) {
    // Process may have already exited
  }

  procInfo.status = 'stopped';
  procInfo.process = null;
  procInfo.logs.push({
    text: '[Toxic] Process stopped by user',
    type: 'warning',
    timestamp: Date.now(),
  });

  return { success: true, message: 'Process stopped' };
}

export function restartBot(userId: string): { success: boolean; message: string; pid?: number } {
  const procInfo = processes.get(userId);
  if (!procInfo) {
    return { success: false, message: 'No process found to restart' };
  }

  const { workingDir, entryPoint } = procInfo;
  return deployBot(userId, workingDir, entryPoint);
}

export function getLogs(userId: string, since?: number): Array<{ text: string; type: string; timestamp: number }> {
  const procInfo = processes.get(userId);
  if (!procInfo) return [];

  if (since) {
    return procInfo.logs.filter(l => l.timestamp > since);
  }
  return procInfo.logs;
}

export function getDeployStatus(userId: string) {
  const procInfo = processes.get(userId);
  if (!procInfo) {
    return { running: false, pid: null, entryPoint: null, uptime: 0, status: 'stopped', logCount: 0 };
  }

  return {
    running: procInfo.status === 'running',
    pid: procInfo.pid,
    entryPoint: procInfo.entryPoint,
    workingDir: procInfo.workingDir,
    uptime: procInfo.status === 'running' ? Date.now() - procInfo.startTime : 0,
    status: procInfo.status,
    logCount: procInfo.logs.length,
    startTime: procInfo.startTime,
  };
}

export function sendCommand(userId: string, command: string): { success: boolean; message: string } {
  const procInfo = processes.get(userId);
  if (!procInfo || !procInfo.process || !procInfo.process.stdin) {
    return { success: false, message: 'No running process to send command to' };
  }

  procInfo.process.stdin.write(command + '\n');
  procInfo.logs.push({
    text: `> ${command}`,
    type: 'normal',
    timestamp: Date.now(),
  });

  return { success: true, message: 'Command sent' };
}

export function getServerStatus() {
  const cpus = os.cpus();
  const totalMemory = os.totalmem();
  const freeMemory = os.freemem();
  const usedMemory = totalMemory - freeMemory;

  // Simple CPU load average
  const loadAvg = os.loadavg()[0];
  const cpuUsage = Math.min((loadAvg / cpus.length) * 100, 100);

  // Disk info - try to read from /proc/meminfo or use df
  let diskTotal = 0;
  let diskFree = 0;
  try {
    const stats = fs.statSync('/');
    // Use os.tmpdir or root
  } catch (e) {
    // ignore
  }

  // Try to get disk info
  try {
    const dfOutput = execSync('df -k / 2>/dev/null || echo "0 0 0"').toString();
    const lines = dfOutput.trim().split('\n');
    if (lines.length >= 2) {
      const parts = lines[1].split(/\s+/);
      if (parts.length >= 4) {
        diskTotal = parseInt(parts[1]) * 1024; // KB to bytes
        diskFree = parseInt(parts[3]) * 1024;
      }
    }
  } catch (e) {
    diskTotal = 10 * 1024 * 1024 * 1024; // 10GB default
    diskFree = 5 * 1024 * 1024 * 1024;
  }

  return {
    hostname: os.hostname(),
    platform: os.platform(),
    arch: os.arch(),
    nodeVersion: process.version,
    uptime: os.uptime(),
    cpuCount: cpus.length,
    cpuModel: cpus[0]?.model || 'Unknown',
    cpuUsage: Math.round(cpuUsage * 100) / 100,
    totalMemory: totalMemory,
    freeMemory: freeMemory,
    usedMemory: usedMemory,
    memoryUsagePercent: Math.round((usedMemory / totalMemory) * 10000) / 100,
    diskTotal,
    diskFree,
    diskUsed: diskTotal - diskFree,
    diskUsagePercent: diskTotal > 0 ? Math.round(((diskTotal - diskFree) / diskTotal) * 10000) / 100 : 0,
    loadAvg: os.loadavg(),
  };
}

export function listFiles(dirPath: string): Array<{ name: string; isDir: boolean; size: number; modified: string }> {
  if (!fs.existsSync(dirPath)) return [];

  const entries = fs.readdirSync(dirPath, { withFileTypes: true });

  // Check if there's a single subdirectory with all the files (common ZIP structure)
  const topDirs = entries.filter(e => e.isDirectory() && !e.name.startsWith('.'));
  const hasRootEntry = entries.some(e => ENTRY_POINTS.includes(e.name) || e.name === 'package.json' || e.name === 'requirements.txt');
  let listDir = dirPath;
  if (!hasRootEntry && topDirs.length === 1) {
    listDir = path.join(dirPath, topDirs[0].name);
  }

  const listEntries = fs.readdirSync(listDir, { withFileTypes: true });
  return listEntries
    .filter(e => !e.name.startsWith('.'))
    .map(e => {
      try {
        const stats = fs.statSync(path.join(listDir, e.name));
        return {
          name: e.name,
          isDir: e.isDirectory(),
          size: e.isDirectory() ? 0 : stats.size,
          modified: stats.mtime.toISOString(),
        };
      } catch {
        return { name: e.name, isDir: e.isDirectory(), size: 0, modified: '' };
      }
    })
    .sort((a, b) => {
      if (a.isDir !== b.isDir) return a.isDir ? -1 : 1;
      return a.name.localeCompare(b.name);
    });
}

export function extractZip(zipPath: string, extractTo: string): { success: boolean; message: string; files?: string[] } {
  try {
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const AdmZip = require('adm-zip');
    const zip = new AdmZip(zipPath);
    
    if (!fs.existsSync(extractTo)) {
      fs.mkdirSync(extractTo, { recursive: true });
    }

    const entries = zip.getEntries();
    const fileNames: string[] = [];

    zip.extractAllTo(extractTo, true);

    for (const entry of entries) {
      if (!entry.isDirectory) {
        fileNames.push(entry.entryName);
      }
    }

    return { success: true, message: `Extracted ${fileNames.length} files`, files: fileNames };
  } catch (e: any) {
    return { success: false, message: `Extraction failed: ${e.message}` };
  }
}

export function detectEntryPoint(dirPath: string): string | null {
  // Check top-level first
  for (const ep of ENTRY_POINTS) {
    if (fs.existsSync(path.join(dirPath, ep))) {
      return ep;
    }
  }

  // If ZIP has a single top-level directory, check inside it
  try {
    const entries = fs.readdirSync(dirPath, { withFileTypes: true });
    const topDirs = entries.filter(e => e.isDirectory() && !e.name.startsWith('.'));
    // If there's exactly one directory and no entry files at root, look inside
    const hasRootEntry = entries.some(e => {
      const name = e.name;
      return ENTRY_POINTS.includes(name);
    });
    if (!hasRootEntry && topDirs.length === 1) {
      const subDir = path.join(dirPath, topDirs[0].name);
      for (const ep of ENTRY_POINTS) {
        if (fs.existsSync(path.join(subDir, ep))) {
          // Return relative path from dirPath
          return topDirs[0].name + '/' + ep;
        }
      }
    }
    // Also check inside all subdirectories as fallback
    for (const dir of topDirs) {
      for (const ep of ENTRY_POINTS) {
        if (fs.existsSync(path.join(dirPath, dir.name, ep))) {
          return dir.name + '/' + ep;
        }
      }
    }
  } catch {
    // ignore
  }

  return null;
}
