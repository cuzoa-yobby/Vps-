import bcrypt from 'bcryptjs';
import { cookies } from 'next/headers';
import { db } from '@/lib/db';

const SALT_ROUNDS = 10;

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, SALT_ROUNDS);
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

export async function getCurrentUser() {
  const cookieStore = await cookies();
  const sessionId = cookieStore.get('session_id')?.value;

  if (!sessionId) return null;

  const user = await db.user.findUnique({
    where: { id: sessionId },
  });

  if (!user) return null;

  return {
    id: user.id,
    username: user.username,
    plan: user.plan,
    status: user.status,
    activatedAt: user.activatedAt,
    expiresAt: user.expiresAt,
    createdAt: user.createdAt,
  };
}

export function setSession(userId: string) {
  return {
    name: 'session_id' as const,
    value: userId,
    httpOnly: true,
    path: '/' as const,
    maxAge: 60 * 60 * 24 * 7, // 7 days
    sameSite: 'lax' as const,
  };
}

export function clearSession() {
  return {
    name: 'session_id' as const,
    value: '',
    httpOnly: true,
    path: '/' as const,
    maxAge: 0,
    sameSite: 'lax' as const,
  };
}
