'use client';

import { useState, useRef, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { useToast } from '@/hooks/use-toast';
import Image from 'next/image';
import {
  Terminal, FileText, Rocket, Settings, Play, RotateCcw, Square,
  ChevronRight, Cpu, HardDrive, Clock, Activity, Upload, Trash2,
  FolderOpen, LogOut, MemoryStick, X, Loader2, AlertCircle,
  CheckCircle2, Info, User, Shield, Calendar, File, Folder, FolderPlus,
  FilePlus, MoreVertical, Home, ArrowLeft, RefreshCw, Move, Package, FileArchive,
  Server, Zap, Lock, Eye, EyeOff, LayoutDashboard, Bot
} from 'lucide-react';

// ============================================================
// TYPES
// ============================================================
interface UserInfo {
  id: string;
  username: string;
  plan: string;
  status: string;
  activatedAt?: string;
  expiresAt?: string;
}

interface ConsoleLine {
  text: string;
  type: 'normal' | 'warning' | 'error' | 'success' | 'info';
  timestamp: number;
}

interface FileEntry {
  id: string;
  userId: string;
  fileName: string;
  filePath: string;
  fileSize: number;
  extracted: boolean;
  extractDir: string | null;
  parsedFiles: string[];
  files: Array<{ name: string; isDir: boolean; size: number; modified: string }>;
  createdAt: string;
}

interface ServerStats {
  hostname: string;
  platform: string;
  arch: string;
  nodeVersion: string;
  uptime: number;
  cpuCount: number;
  cpuModel: string;
  cpuUsage: number;
  totalMemory: number;
  freeMemory: number;
  usedMemory: number;
  memoryUsagePercent: number;
  diskTotal: number;
  diskFree: number;
  diskUsed: number;
  diskUsagePercent: number;
  loadAvg: number[];
}

interface DeployInfo {
  running: boolean;
  pid: number | null;
  entryPoint: string | null;
  workingDir: string | null;
  uptime: number;
  status: string;
  logCount: number;
  startTime: number;
}

interface BrowserFile {
  name: string;
  isDir: boolean;
  size: number;
  modified: string;
  path: string;
}

type PageState = 'login' | 'dashboard';
type TabState = 'servers' | 'console' | 'files' | 'deploy' | 'settings';

// ============================================================
// HELPERS
// ============================================================
function formatBytes(bytes: number): string {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
}

function formatUptime(seconds: number): string {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  if (h > 0) return `${h}h ${m}m ${s}s`;
  if (m > 0) return `${m}m ${s}s`;
  return `${s}s`;
}

function formatUptimeLong(seconds: number): string {
  const d = Math.floor(seconds / 86400);
  const h = Math.floor((seconds % 86400) / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  if (d > 0) return `${d}d ${h}h ${m}m`;
  return `${h}h ${m}m`;
}

function timeAgo(dateStr: string): string {
  const now = Date.now();
  const then = new Date(dateStr).getTime();
  const diff = now - then;
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'Just now';
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  return `${days}d ago`;
}

// ============================================================
// MAIN APP
// ============================================================
export default function ToxicPanel() {
  const [page, setPage] = useState<PageState>('login');
  const [tab, setTab] = useState<TabState>('servers');
  const [user, setUser] = useState<UserInfo | null>(null);
  const [loading, setLoading] = useState(true);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    fetch('/api/auth/me')
      .then(res => { if (res.ok) return res.json(); throw new Error(); })
      .then(data => { setUser(data.user); setPage('dashboard'); })
      .catch(() => { setPage('login'); })
      .finally(() => setLoading(false));
  }, []);

  const handleLogin = async (username: string, password: string) => {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password }),
    });
    const data = await res.json();
    if (!res.ok) {
      toast({ title: 'Login Failed', description: data.error, variant: 'destructive' });
      return false;
    }
    setUser(data.user);
    setPage('dashboard');
    toast({ title: 'Welcome back!', description: `Logged in as ${data.user.username}` });
    return true;
  };

  const handleLogout = async () => {
    await fetch('/api/auth/logout', { method: 'POST' });
    setUser(null);
    setPage('login');
    setTab('console');
    toast({ title: 'Logged out', description: 'See you next time!' });
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background login-bg">
        <div className="flex flex-col items-center gap-5 animate-fade-in">
          <div className="relative animate-logo-entrance">
            <div className="absolute inset-0 rounded-2xl bg-primary/10 blur-xl animate-pulse" />
            <Image src="/toxic-logo.png" alt="Loading" width={64} height={64} className="relative rounded-xl" />
          </div>
          <div className="flex flex-col items-center gap-2">
            <p className="text-muted-foreground text-sm font-medium">Loading panel...</p>
            <div className="w-24 h-0.5 rounded-full premium-loading" />
          </div>
        </div>
      </div>
    );
  }

  if (page === 'login') {
    return <LoginPage onLogin={handleLogin} />;
  }

  const navItems: Array<{ id: TabState; label: string; icon: React.ReactNode }> = [
    { id: 'servers', label: 'Servers', icon: <LayoutDashboard className="w-4.5 h-4.5" /> },
    { id: 'console', label: 'Console', icon: <Terminal className="w-4.5 h-4.5" /> },
    { id: 'files', label: 'File Manager', icon: <FolderOpen className="w-4.5 h-4.5" /> },
    { id: 'deploy', label: 'Deploy', icon: <Rocket className="w-4.5 h-4.5" /> },
    { id: 'settings', label: 'Settings', icon: <Settings className="w-4.5 h-4.5" /> },
  ];

  return (
    <div className="min-h-screen flex bg-background relative overflow-hidden">
      {/* Background effects */}
      <div className="bg-radial-glow fixed inset-0 pointer-events-none z-0" />
      <div className="particle-dot particle-dot-1" style={{ top: '15%', left: '8%' }} />
      <div className="particle-dot particle-dot-2" style={{ top: '25%', right: '12%' }} />
      <div className="particle-dot particle-dot-3" style={{ top: '45%', left: '75%' }} />
      <div className="particle-dot particle-dot-4" style={{ top: '65%', left: '20%' }} />
      <div className="particle-dot particle-dot-5" style={{ top: '80%', right: '25%' }} />
      <div className="floating-orb floating-orb-1" style={{ top: '10%', left: '5%' }} />
      <div className="floating-orb floating-orb-2" style={{ top: '60%', right: '10%' }} />

      {/* Discord-style Sidebar */}
      <aside className={`discord-sidebar relative z-10 flex flex-col h-screen sticky top-0 transition-all duration-300 ${sidebarCollapsed ? 'w-[68px]' : 'w-56'}`}>
        {/* Server Icon */}
        <div className="flex items-center justify-center h-12 border-b border-border/30 shrink-0">
          <div className="relative group cursor-pointer" onClick={() => setSidebarCollapsed(!sidebarCollapsed)}>
            <div className={`absolute inset-0 rounded-xl bg-primary/10 blur-md animate-neon-glow transition-all ${sidebarCollapsed ? 'w-10 h-10' : 'w-12 h-12'}`} />
            <Image src="/toxic-logo.png" alt="Toxic Panel" width={sidebarCollapsed ? 40 : 48} height={sidebarCollapsed ? 40 : 48} className="relative rounded-xl transition-all" />
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-2 py-3 space-y-1 overflow-y-auto">
          <div className={`mb-2 px-2 ${sidebarCollapsed ? 'hidden' : ''}`}>
            <p className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground/40">Navigation</p>
          </div>
          {navItems.map((item, i) => (
            <button
              key={item.id}
              onClick={() => setTab(item.id)}
              className={`sidebar-nav-item w-full animate-slide-in-left ${tab === item.id ? 'active' : ''}`}
              style={{ animationDelay: `${i * 0.05}s` }}
              title={sidebarCollapsed ? item.label : undefined}
            >
              <span className={`shrink-0 ${tab === item.id ? 'text-primary' : ''}`}>{item.icon}</span>
              {!sidebarCollapsed && <span>{item.label}</span>}
            </button>
          ))}

          <div className={`my-3 h-px bg-border/20 ${sidebarCollapsed ? 'mx-2' : ''}`} />

          <div className={`px-2 ${sidebarCollapsed ? 'hidden' : ''}`}>
            <p className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground/40 mb-1">System</p>
          </div>

          <div className={`sidebar-nav-item ${sidebarCollapsed ? 'justify-center' : ''}`}>
            <span className="shrink-0 text-muted-foreground/50"><Server className="w-4.5 h-4.5" /></span>
            {!sidebarCollapsed && <span className="text-muted-foreground/50 text-xs">Status: Online</span>}
          </div>
        </nav>

        {/* User panel at bottom */}
        <div className={`border-t border-border/30 p-2 shrink-0 ${sidebarCollapsed ? 'flex flex-col items-center gap-2' : ''}`}>
          {!sidebarCollapsed && user && (
            <div className="flex items-center gap-2.5 px-2 py-1.5 rounded-lg hover:bg-white/5 transition-colors cursor-pointer">
              <div className="w-8 h-8 rounded-full bg-primary/15 flex items-center justify-center border border-primary/20">
                <User className="w-4 h-4 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-foreground/90 truncate">{user.username}</p>
                <p className="text-[10px] text-muted-foreground/50 uppercase tracking-wider">{user.plan}</p>
              </div>
              <div className="w-2 h-2 rounded-full bg-green-500 shrink-0" />
            </div>
          )}
          <button
            onClick={handleLogout}
            className={`flex items-center gap-2 text-xs text-muted-foreground/50 hover:text-red-400 transition-colors px-2 py-1.5 rounded-lg hover:bg-red-500/5 ${sidebarCollapsed ? 'justify-center' : 'w-full'}`}
            title={sidebarCollapsed ? 'Logout' : undefined}
          >
            <LogOut className="w-4 h-4 shrink-0" />
            {!sidebarCollapsed && 'Logout'}
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-h-screen relative z-10 overflow-hidden">
        {/* Top bar */}
        <header className="glass-header h-12 flex items-center justify-between px-4 shrink-0">
          <div className="flex items-center gap-3">
            <h2 className="text-sm font-semibold capitalize">{tab}</h2>
            <div className="discord-badge">
              <Zap className="w-3 h-3" />
              {user?.plan || 'free'}
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5">
              <div className="w-2 h-2 rounded-full bg-green-500 animate-breathing" />
              <span className="text-[11px] text-muted-foreground/60">Online</span>
            </div>
            <div className="h-4 w-px bg-border/30" />
            <span className="text-xs text-muted-foreground/50 font-mono">{user?.username}</span>
          </div>
        </header>
        <div className="header-glow-line" />

        {/* Content */}
        <div className="flex-1 overflow-hidden">
          {tab === 'servers' && user && <ServersTab userId={user.id} onOpenConsole={() => setTab('console')} />}
          {tab === 'console' && user && <ConsoleTab userId={user.id} />}
          {tab === 'files' && user && <FilesTab userId={user.id} />}
          {tab === 'deploy' && user && <DeployTab userId={user.id} />}
          {tab === 'settings' && user && <SettingsTab user={user} />}
        </div>

        {/* Footer */}
        <div className="gradient-footer-border py-2 px-4 text-center shrink-0">
          <p className="text-[11px] text-muted-foreground/30">
            ToxicPanel &copy; {new Date().getFullYear()} &middot; Discord Bot Hosting
          </p>
        </div>
      </main>
    </div>
  );
}

// ============================================================
// LOGIN PAGE — DISCORD-STYLE PREMIUM
// ============================================================
function LoginPage({ onLogin }: { onLogin: (username: string, password: string) => Promise<boolean> }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !password.trim()) { setError('Please fill in all fields'); return; }
    setIsLoading(true);
    setError('');
    const ok = await onLogin(username.trim(), password.trim());
    setIsLoading(false);
    if (!ok) setError('Invalid username or password');
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 login-bg bg-grid-pattern-animated relative overflow-hidden">
      {/* Background orbs */}
      <div className="floating-orb floating-orb-1" style={{ top: '8%', left: '15%' }} />
      <div className="floating-orb floating-orb-2" style={{ top: '70%', right: '10%' }} />
      <div className="floating-orb floating-orb-3" style={{ bottom: '15%', left: '60%' }} />
      <div className="particle-dot particle-dot-1" style={{ top: '20%', left: '25%' }} />
      <div className="particle-dot particle-dot-2" style={{ top: '40%', right: '20%' }} />
      <div className="particle-dot particle-dot-3" style={{ top: '60%', left: '70%' }} />
      <div className="particle-dot particle-dot-4" style={{ top: '75%', left: '15%' }} />
      <div className="particle-dot particle-dot-5" style={{ top: '30%', right: '35%' }} />
      <div className="absolute inset-0 bg-grid-pattern opacity-30 pointer-events-none" />
      <div className="absolute top-1/4 -left-32 w-64 h-64 rounded-full bg-primary/5 blur-3xl pointer-events-none animate-pulse" />
      <div className="absolute bottom-1/4 -right-32 w-80 h-80 rounded-full bg-primary/3 blur-3xl pointer-events-none animate-pulse" style={{ animationDelay: '1s' }} />

      <div className="w-full max-w-[420px] relative z-10">
        {/* Login card */}
        <div className="glass-card glow-blurple-strong rounded-2xl overflow-hidden animate-fade-in-up">
          <div className="h-1 w-full bg-gradient-to-r from-transparent via-primary/60 to-transparent" />

          <div className="p-8">
            {/* Logo & branding */}
            <div className="flex flex-col items-center mb-8">
              <div className="relative mb-5 animate-logo-entrance">
                <div className="absolute -inset-5 rounded-2xl bg-primary/10 blur-xl animate-neon-glow" />
                <div className="relative w-20 h-20 p-1 rounded-2xl bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center">
                  <Image src="/toxic-logo.png" alt="Toxic Panel" width={68} height={68} className="rounded-xl mx-auto" />
                </div>
              </div>
              <h1 className="text-3xl font-bold tracking-tight text-glow-strong animate-fade-in-up stagger-2">
                Toxic<span className="blurple-text">Panel</span>
              </h1>
              <p className="text-muted-foreground/60 text-sm mt-1.5 animate-fade-in stagger-3">
                Discord Bot Hosting &mdash; Sign in
              </p>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="space-y-5 animate-fade-in-up stagger-3">
              {error && (
                <div className="flex items-center gap-2.5 p-3.5 rounded-xl bg-destructive/10 border border-destructive/15 text-destructive text-sm animate-scale-in">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  {error}
                </div>
              )}

              <div className="space-y-2">
                <label className="text-xs font-semibold text-muted-foreground/70 uppercase tracking-wider">Username</label>
                <div className="relative">
                  <div className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground/30">
                    <User className="w-4 h-4" />
                  </div>
                  <Input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="Enter your username"
                    className="premium-input bg-background/60 border-border/40 h-11 pl-10 rounded-xl"
                    disabled={isLoading}
                    autoComplete="username"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-semibold text-muted-foreground/70 uppercase tracking-wider">Password</label>
                <div className="relative">
                  <div className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground/30">
                    <Lock className="w-4 h-4" />
                  </div>
                  <Input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter your password"
                    className="premium-input bg-background/60 border-border/40 h-11 pl-10 pr-10 rounded-xl"
                    disabled={isLoading}
                    autoComplete="current-password"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground/30 hover:text-muted-foreground/60 transition-colors"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <Button
                type="submit"
                className="w-full btn-discord-login text-white font-semibold h-11 rounded-xl text-sm"
                disabled={isLoading}
              >
                {isLoading ? (
                  <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Signing in...</>
                ) : (
                  <><LogOut className="w-4 h-4 mr-2" /> Login</>
                )}
              </Button>
            </form>

            {/* Help link */}
            <div className="mt-6 text-center animate-fade-in stagger-4">
              <p className="text-xs text-muted-foreground/40">
                Need help? Contact{' '}
                <a href="https://t.me/Yobby0" target="_blank" rel="noopener noreferrer" className="text-primary/70 hover:text-primary transition-colors">
                  @Yobby0
                </a>
              </p>
            </div>
          </div>
        </div>

        <div className="text-center mt-6 space-y-3 animate-fade-in stagger-5">
          <div className="flex items-center justify-center gap-4 text-[11px] text-muted-foreground/30">
            <span className="flex items-center gap-1"><Shield className="w-3 h-3" /> Secure</span>
            <span className="w-1 h-1 rounded-full bg-muted-foreground/20" />
            <span className="flex items-center gap-1"><Zap className="w-3 h-3" /> Fast</span>
            <span className="w-1 h-1 rounded-full bg-muted-foreground/20" />
            <span className="flex items-center gap-1"><Server className="w-3 h-3" /> Reliable</span>
          </div>
        </div>
      </div>
    </div>
  );
}

// ============================================================
// SERVERS TAB — Bot List (bot-hosting.net style)
// ============================================================
function ServersTab({ userId, onOpenConsole }: { userId: string; onOpenConsole: () => void }) {
  const [files, setFiles] = useState<FileEntry[]>([]);
  const [deployInfo, setDeployInfo] = useState<DeployInfo | null>(null);
  const [loading, setLoading] = useState(true);
  const [deploying, setDeploying] = useState<string | null>(null);
  const [selectedDir, setSelectedDir] = useState<string | null>(null);
  const [customEntry, setCustomEntry] = useState('');
  const { toast } = useToast();

  const loadData = useCallback(async () => {
    try {
      const [filesRes, statusRes] = await Promise.all([
        fetch('/api/files/list'),
        fetch('/api/deploy/status'),
      ]);
      if (filesRes.ok) {
        const data = await filesRes.json();
        setFiles(data.files || []);
        const extracted = data.files?.find((f: FileEntry) => f.extracted && f.extractDir);
        if (extracted && !selectedDir) setSelectedDir(extracted.extractDir);
      }
      if (statusRes.ok) setDeployInfo(await statusRes.json());
    } catch { /* silent */ }
    finally { setLoading(false); }
  }, [selectedDir]);

  useEffect(() => { loadData(); }, [loadData]);

  const handleDeploy = async (extractDir: string) => {
    setDeploying(extractDir);
    try {
      const body: any = { extractDir };
      if (customEntry.trim()) body.entryPoint = customEntry.trim();
      const res = await fetch('/api/deploy/start', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      const data = await res.json();
      if (!res.ok) {
        toast({ title: 'Deploy Failed', description: data.error, variant: 'destructive' });
      } else {
        toast({ title: 'Deployed!', description: `Bot started successfully (PID: ${data.pid})` });
        onOpenConsole();
      }
    } catch {
      toast({ title: 'Error', description: 'Deployment failed', variant: 'destructive' });
    }
    finally { setDeploying(null); loadData(); }
  };

  const handleStop = async () => {
    try {
      await fetch('/api/deploy/stop', { method: 'POST' });
      toast({ title: 'Stopped', description: 'Bot stopped' });
      loadData();
    } catch { toast({ title: 'Error', description: 'Failed to stop', variant: 'destructive' }); }
  };

  const handleRestart = async () => {
    try {
      await fetch('/api/deploy/restart', { method: 'POST' });
      toast({ title: 'Restarted', description: 'Bot restarted' });
      loadData();
    } catch { toast({ title: 'Error', description: 'Failed to restart', variant: 'destructive' }); }
  };

  // Build bot list from extracted projects
  const botProjects = files.filter(f => f.extracted && f.extractDir);
  const isRunning = deployInfo?.running || false;

  if (loading) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="relative">
          <Loader2 className="w-6 h-6 animate-spin text-muted-foreground/40" />
          <div className="absolute inset-0 rounded-full bg-primary/10 blur-md animate-pulse" />
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-4">
      {/* Server List Header */}
      <div className="flex items-center justify-between mb-2">
        <div>
          <h2 className="text-base font-semibold text-foreground/90">Your Servers</h2>
          <p className="text-xs text-muted-foreground/50 mt-0.5">Manage and deploy your Discord bots</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5">
            <div className="relative">
              <div className={`w-2 h-2 rounded-full ${isRunning ? 'bg-green-500' : 'bg-red-500/70'}`} />
              {isRunning && <div className="absolute inset-0 w-2 h-2 rounded-full bg-green-500 animate-breathing" />}
            </div>
            <span className="text-[11px] text-muted-foreground/60">{isRunning ? 'Running' : 'Offline'}</span>
          </div>
        </div>
      </div>

      {/* Bot Server Cards */}
      {botProjects.length === 0 ? (
        <div className="premium-card p-10 text-center animate-card-enter">
          <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
            <Bot className="w-8 h-8 text-primary/50" />
          </div>
          <h3 className="text-sm font-semibold text-foreground/70 mb-1.5">No Servers Yet</h3>
          <p className="text-xs text-muted-foreground/50 max-w-xs mx-auto">
            Upload a ZIP file in the File Manager and extract it to create your first bot server.
          </p>
          <Button
            onClick={() => {}}
            className="mt-5 bg-primary hover:bg-primary/90 text-primary-foreground text-xs rounded-xl btn-glow-blurple"
          >
            <Upload className="w-3.5 h-3.5 mr-1.5" /> Upload Bot Files
          </Button>
        </div>
      ) : (
        <div className="space-y-3">
          {botProjects.map((bot, index) => {
            const botName = bot.fileName.replace(/\.zip$/i, '').replace(/[-_]/g, ' ');
            const isThisBotRunning = isRunning && deployInfo?.workingDir?.includes(bot.extractDir || '');
            const statusColor = isThisBotRunning ? 'bg-green-500' : 'bg-red-500/60';
            const statusBarColor = isThisBotRunning
              ? 'bg-gradient-to-b from-green-400 to-green-600'
              : 'bg-gradient-to-b from-red-400/60 to-red-600/60';
            const fileCount = bot.files?.length || 0;

            return (
              <div
                key={bot.id}
                className={`server-list-card group relative overflow-hidden rounded-xl animate-card-enter`}
                style={{ animationDelay: `${index * 0.08}s` }}
              >
                {/* Status bar on right edge */}
                <div className={`absolute right-0 top-0 bottom-0 w-1 ${statusBarColor} rounded-l-sm transition-all duration-300`} />

                <div className="flex items-center gap-4 p-4 pr-5">
                  {/* Bot Icon */}
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 transition-all duration-300 ${
                    isThisBotRunning
                      ? 'bg-green-500/15 border border-green-500/20 shadow-[0_0_12px_oklch(0.55_0.22_25_/_0.15)]'
                      : 'bg-muted/50 border border-border/30'
                  }`}>
                    <Bot className={`w-5 h-5 ${isThisBotRunning ? 'text-green-400' : 'text-muted-foreground/40'}`} />
                  </div>

                  {/* Bot Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5">
                      <h3 className="text-sm font-semibold text-foreground/90 truncate">{botName}</h3>
                      <div className={`flex items-center gap-1 px-1.5 py-0.5 rounded-md text-[10px] font-semibold uppercase tracking-wider ${
                        isThisBotRunning
                          ? 'bg-green-500/10 text-green-400 border border-green-500/15'
                          : 'bg-red-500/8 text-red-400/70 border border-red-500/10'
                      }`}>
                        <div className={`w-1.5 h-1.5 rounded-full ${statusColor}`} />
                        {isThisBotRunning ? 'Online' : 'Offline'}
                      </div>
                    </div>
                    <p className="text-xs text-muted-foreground/50">
                      Discord Bot Server &middot; {fileCount} file{fileCount !== 1 ? 's' : ''}
                      {bot.createdAt && ` &middot; ${timeAgo(bot.createdAt)}`}
                    </p>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-2 shrink-0">
                    {isThisBotRunning ? (
                      <>
                        <Button
                          onClick={handleRestart}
                          variant="secondary"
                          size="sm"
                          className="h-8 px-3 text-xs rounded-lg"
                        >
                          <RotateCcw className="w-3 h-3 mr-1.5" /> Restart
                        </Button>
                        <Button
                          onClick={handleStop}
                          size="sm"
                          className="h-8 px-3 text-xs rounded-lg bg-red-600/80 hover:bg-red-600 text-white"
                        >
                          <Square className="w-3 h-3 mr-1.5" /> Stop
                        </Button>
                      </>
                    ) : (
                      <Button
                        onClick={() => handleDeploy(bot.extractDir!)}
                        disabled={deploying === bot.extractDir}
                        size="sm"
                        className="h-8 px-4 text-xs rounded-lg bg-green-600/80 hover:bg-green-600 text-white btn-glow-blurple"
                      >
                        {deploying === bot.extractDir ? (
                          <Loader2 className="w-3 h-3 mr-1.5 animate-spin" />
                        ) : (
                          <Rocket className="w-3 h-3 mr-1.5" />
                        )}
                        Deploy
                      </Button>
                    )}
                    <Button
                      onClick={onOpenConsole}
                      variant="ghost"
                      size="sm"
                      className="h-8 px-2 text-xs text-muted-foreground/50 hover:text-foreground/70 rounded-lg"
                      title="Open Console"
                    >
                      <Terminal className="w-3.5 h-3.5" />
                    </Button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Quick Deploy Section */}
      {!isRunning && botProjects.length > 0 && (
        <div className="premium-card p-4 animate-card-enter stagger-3">
          <div className="flex items-center gap-2.5 mb-3">
            <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
              <Rocket className="w-4 h-4 text-primary" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-foreground/90">Quick Deploy</h3>
              <p className="text-[11px] text-muted-foreground/50">Select a project and entry point</p>
            </div>
          </div>
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="flex-1">
              <select
                value={selectedDir || ''}
                onChange={(e) => setSelectedDir(e.target.value || null)}
                className="w-full bg-background/50 border border-border/40 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-primary/50"
              >
                <option value="">Select a project...</option>
                {botProjects.map(f => (
                  <option key={f.id} value={f.extractDir || ''}>{f.fileName.replace(/\.zip$/i, '')}</option>
                ))}
              </select>
            </div>
            <div className="flex-1">
              <Input
                value={customEntry}
                onChange={(e) => setCustomEntry(e.target.value)}
                placeholder="Entry point (auto-detected)"
                className="premium-input bg-background/50 border-border/40 text-sm rounded-lg h-9"
              />
            </div>
            <Button
              onClick={() => selectedDir && handleDeploy(selectedDir)}
              disabled={!selectedDir || !!deploying}
              className="bg-green-600/80 hover:bg-green-600 text-white text-sm rounded-lg h-9 px-5 btn-glow-blurple"
            >
              {deploying ? <Loader2 className="w-4 h-4 mr-1.5 animate-spin" /> : <Rocket className="w-4 h-4 mr-1.5" />}
              Deploy
            </Button>
          </div>
        </div>
      )}

      {/* Active Process Info */}
      {isRunning && deployInfo && (
        <div className="premium-card p-4 animate-card-enter stagger-4">
          <div className="flex items-center gap-2.5 mb-3">
            <div className="w-8 h-8 rounded-lg bg-green-500/10 flex items-center justify-center">
              <Activity className="w-4 h-4 text-green-400" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-foreground/90">Active Process</h3>
              <p className="text-[11px] text-muted-foreground/50">Your bot is currently running</p>
            </div>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            {[
              { label: 'Status', value: <div className="flex items-center gap-1.5"><div className="w-2 h-2 rounded-full bg-green-500 animate-breathing" /><span className="text-xs font-mono text-green-400 capitalize">{deployInfo.status}</span></div> },
              { label: 'PID', value: <p className="text-xs font-mono">{deployInfo.pid || 'N/A'}</p> },
              { label: 'Entry Point', value: <p className="text-xs font-mono">{deployInfo.entryPoint || 'N/A'}</p> },
              { label: 'Uptime', value: <p className="text-xs font-mono">{deployInfo.running ? formatUptime(deployInfo.uptime / 1000) : 'N/A'}</p> },
            ].map((item, i) => (
              <div key={i} className="premium-stat p-2.5">
                <p className="text-[10px] text-muted-foreground/50 font-semibold uppercase tracking-wider mb-1">{item.label}</p>
                {item.value}
              </div>
            ))}
          </div>
          <div className="flex items-center gap-2 mt-3 pt-3 border-t border-border/20">
            <Button onClick={onOpenConsole} variant="secondary" size="sm" className="h-8 text-xs rounded-lg">
              <Terminal className="w-3.5 h-3.5 mr-1.5" /> Open Console
            </Button>
            <Button onClick={handleRestart} variant="secondary" size="sm" className="h-8 text-xs rounded-lg">
              <RotateCcw className="w-3.5 h-3.5 mr-1.5" /> Restart
            </Button>
            <Button onClick={handleStop} size="sm" className="h-8 text-xs rounded-lg bg-red-600/80 hover:bg-red-600 text-white">
              <Square className="w-3.5 h-3.5 mr-1.5" /> Stop
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}

// ============================================================
// CONSOLE TAB
// ============================================================
function ConsoleTab({ userId }: { userId: string }) {
  const [logs, setLogs] = useState<ConsoleLine[]>([]);
  const [command, setCommand] = useState('');
  const [deployInfo, setDeployInfo] = useState<DeployInfo | null>(null);
  const [serverStats, setServerStats] = useState<ServerStats | null>(null);
  const [isPolling, setIsPolling] = useState(true);
  const consoleEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  useEffect(() => { consoleEndRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [logs]);

  useEffect(() => {
    if (!isPolling) return;
    let lastTimestamp = 0;
    const poll = async () => {
      try {
        const [logsRes, statusRes, serverRes] = await Promise.all([
          fetch(`/api/deploy/logs?since=${lastTimestamp}`),
          fetch('/api/deploy/status'),
          fetch('/api/server/status'),
        ]);
        if (logsRes.ok) {
          const data = await logsRes.json();
          if (data.logs && data.logs.length > 0) {
            setLogs(prev => [...prev, ...data.logs]);
            lastTimestamp = data.logs[data.logs.length - 1].timestamp;
          }
        }
        if (statusRes.ok) setDeployInfo(await statusRes.json());
        if (serverRes.ok) setServerStats(await serverRes.json());
      } catch { /* silent */ }
    };
    poll();
    const interval = setInterval(poll, 2000);
    return () => clearInterval(interval);
  }, [isPolling]);

  const handleCommand = async () => {
    if (!command.trim() || !deployInfo?.running) return;
    const cmd = command.trim();
    setLogs(prev => [...prev, { text: `> ${cmd}`, type: 'normal', timestamp: Date.now() }]);
    setCommand('');
    try {
      const res = await fetch('/api/deploy/command', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ command: cmd }),
      });
      const data = await res.json();
      if (!res.ok) toast({ title: 'Command Failed', description: data.error, variant: 'destructive' });
    } catch { toast({ title: 'Error', description: 'Failed to send command', variant: 'destructive' }); }
  };

  const handleAction = async (action: 'start' | 'stop' | 'restart', extractDir?: string) => {
    try {
      if (action === 'start' && extractDir) {
        const res = await fetch('/api/deploy/start', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ extractDir }),
        });
        const data = await res.json();
        if (!res.ok) toast({ title: `${action} Failed`, description: data.error, variant: 'destructive' });
        else { toast({ title: `${action} Successful`, description: data.message || `Process ${action}ed` }); setLogs([]); }
        return;
      }
      const res = await fetch(`/api/deploy/${action}`, { method: 'POST' });
      const data = await res.json();
      if (!res.ok) toast({ title: `${action} Failed`, description: data.error, variant: 'destructive' });
      else { toast({ title: `${action} Successful`, description: data.message || `Process ${action}ed` }); if (action === 'restart') setLogs([]); }
    } catch { toast({ title: 'Error', description: `Failed to ${action}`, variant: 'destructive' }); }
  };

  return (
    <div className="flex flex-col h-full animate-fade-in">
      {/* Controls */}
      <div className="console-controls-bar flex items-center gap-2 px-4 py-2.5 flex-wrap shrink-0">
        <Button onClick={() => handleAction('start')} disabled={deployInfo?.running}
          className="bg-green-600/80 hover:bg-green-600 text-white h-8 px-4 text-xs rounded-lg">
          <Rocket className="w-3 h-3 mr-1.5" /> Deploy
        </Button>
        <Button onClick={() => handleAction('restart')} disabled={!deployInfo?.running}
          variant="secondary" className="h-8 px-4 text-xs rounded-lg">
          <RotateCcw className="w-3 h-3 mr-1.5" /> Restart
        </Button>
        <Button onClick={() => handleAction('stop')} disabled={!deployInfo?.running}
          className="bg-red-600/80 hover:bg-red-600 text-white h-8 px-4 text-xs rounded-lg">
          <Square className="w-3 h-3 mr-1.5" /> Stop
        </Button>
        <Button onClick={() => setLogs([])} variant="ghost"
          className="h-8 px-3 text-xs text-muted-foreground/50 hover:text-foreground/70 rounded-lg">
          Clear
        </Button>
        <div className="ml-auto flex items-center gap-2">
          {deployInfo?.entryPoint && <Badge variant="outline" className="text-[10px] font-mono bg-background/50 border-border/40 rounded-md">{deployInfo.entryPoint}</Badge>}
          {deployInfo?.pid && <Badge variant="outline" className="text-[10px] font-mono bg-background/50 border-border/40 rounded-md">PID: {deployInfo.pid}</Badge>}
          <div className="flex items-center gap-1.5">
            <div className="relative">
              <div className={`w-2 h-2 rounded-full ${deployInfo?.running ? 'bg-green-500' : deployInfo?.status === 'starting' ? 'bg-yellow-500' : 'bg-red-500'}`} />
              {(deployInfo?.running || deployInfo?.status === 'starting') && (
                <div className={`absolute inset-0 w-2 h-2 rounded-full animate-breathing ${deployInfo?.running ? 'bg-green-500' : 'bg-yellow-500'}`} />
              )}
            </div>
            <span className="text-xs text-muted-foreground/60 capitalize font-medium">{deployInfo?.status || 'stopped'}</span>
          </div>
        </div>
      </div>

      {/* Console output */}
      <div className="flex-1 bg-terminal p-4 overflow-y-auto min-h-0 relative scan-lines">
        <div className="absolute top-0 left-0 right-0 h-8 bg-gradient-to-b from-background/20 to-transparent pointer-events-none z-10" />
        <div className="console-output space-y-0 pt-2">
          {logs.length === 0 && (
            <div className="text-dim flex items-center gap-2">
              {deployInfo?.running ? (
                <>
                  <span className="inline-block w-2 h-4 bg-primary/40 animate-blink-cursor rounded-sm" />
                  <span className="animate-typing-dots">Waiting for output</span>
                  <span className="inline-block w-1.5 h-1.5 rounded-full bg-primary/40 animate-typing-dots" style={{ animationDelay: '0.2s' }} />
                  <span className="inline-block w-1.5 h-1.5 rounded-full bg-primary/40 animate-typing-dots" style={{ animationDelay: '0.4s' }} />
                  <span className="inline-block w-1.5 h-1.5 rounded-full bg-primary/40 animate-typing-dots" style={{ animationDelay: '0.6s' }} />
                </>
              ) : 'No process running. Use the Deploy tab to start a bot.'}
            </div>
          )}
          {logs.map((line, i) => (
            <div key={`${line.timestamp}-${i}`} className={`whitespace-pre-wrap break-all ${
              line.type === 'warning' ? 'text-warning' : line.type === 'error' ? 'text-error' :
              line.type === 'success' ? 'text-success' : line.type === 'info' ? 'text-info' : 'text-terminal-fg'
            }`}>{line.text || '\u00A0'}</div>
          ))}
          {deployInfo?.running && logs.length > 0 && (
            <span className="inline-block w-2 h-4 bg-primary/60 animate-blink-cursor rounded-sm ml-0.5" />
          )}
          <div ref={consoleEndRef} />
        </div>
      </div>

      {/* Command input */}
      <div className="border-t border-border/30 glass-subtle px-4 py-2.5 shrink-0">
        <div className="flex items-center gap-2.5">
          <div className="w-6 h-6 rounded-md bg-primary/10 flex items-center justify-center">
            <ChevronRight className="w-3.5 h-3.5 text-primary" />
          </div>
          <Input value={command} onChange={(e) => setCommand(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleCommand()}
            placeholder="Type a command..." className="border-0 bg-transparent focus-visible:ring-0 text-sm font-mono placeholder:text-muted-foreground/30"
            disabled={!deployInfo?.running} />
          {deployInfo?.running && !command && <span className="w-2 h-4 bg-primary/50 animate-blink-cursor rounded-sm" />}
        </div>
      </div>

      {/* Server Stats */}
      {serverStats && (
        <div className="border-t border-border/30 bg-card/30 p-3 backdrop-blur-sm shrink-0 animate-fade-in-up">
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2.5">
            <MiniStat icon={<Clock className="w-3.5 h-3.5" />} label="Uptime" value={formatUptimeLong(serverStats.uptime)} color="text-green-400" />
            <MiniStat icon={<Cpu className="w-3.5 h-3.5" />} label="CPU" value={`${serverStats.cpuUsage.toFixed(1)}%`} color="text-purple-400" />
            <MiniStat icon={<MemoryStick className="w-3.5 h-3.5" />} label="Memory" value={`${formatBytes(serverStats.usedMemory)} / ${formatBytes(serverStats.totalMemory)}`} color="text-cyan-400" progress={serverStats.memoryUsagePercent / 100} />
            <MiniStat icon={<HardDrive className="w-3.5 h-3.5" />} label="Disk" value={`${formatBytes(serverStats.diskUsed)} / ${formatBytes(serverStats.diskTotal)}`} color="text-orange-400" progress={serverStats.diskUsagePercent / 100} />
            <MiniStat icon={<Activity className="w-3.5 h-3.5" />} label="Load Avg" value={serverStats.loadAvg[0].toFixed(2)} color="text-rose-400" />
          </div>
        </div>
      )}
    </div>
  );
}

// ============================================================
// MINI STAT
// ============================================================
function MiniStat({ icon, label, value, color, progress }: {
  icon: React.ReactNode; label: string; value: string; color: string; progress?: number;
}) {
  return (
    <div className="premium-stat p-2.5">
      <div className="flex items-center gap-1.5 mb-1">
        <span className={color}>{icon}</span>
        <span className="text-[10px] text-muted-foreground/50 font-semibold uppercase tracking-wider">{label}</span>
      </div>
      <p className="text-xs font-mono font-medium truncate text-foreground/90">{value}</p>
      {progress !== undefined && (
        <div className="mt-1.5 h-1 bg-muted/50 rounded-full overflow-hidden">
          <div className="h-full rounded-full transition-all duration-500" style={{
            width: `${Math.min(progress * 100, 100)}%`,
            background: `linear-gradient(90deg, oklch(0.55 0.22 265 / 0.8), oklch(0.55 0.22 265 / 0.4))`,
          }} />
        </div>
      )}
    </div>
  );
}

// ============================================================
// FILES TAB
// ============================================================
function FilesTab({ userId }: { userId: string }) {
  const [currentPath, setCurrentPath] = useState('');
  const [files, setFiles] = useState<BrowserFile[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [dragOver, setDragOver] = useState(false);
  const [selectedFiles, setSelectedFiles] = useState<Set<string>>(new Set());
  const [showMkdirModal, setShowMkdirModal] = useState(false);
  const [showNewFileModal, setShowNewFileModal] = useState(false);
  const [showMoveModal, setShowMoveModal] = useState(false);
  const [showRenameModal, setShowRenameModal] = useState(false);
  const [showContextFor, setShowContextFor] = useState<BrowserFile | null>(null);
  const [mkdirName, setMkdirName] = useState('');
  const [newFileName, setNewFileName] = useState('');
  const [renameOld, setRenameOld] = useState('');
  const [renameNew, setRenameNew] = useState('');
  const [moveDest, setMoveDest] = useState('');
  const [operationMsg, setOperationMsg] = useState<string | null>(null);
  const [parentPath, setParentPath] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const loadDirectory = useCallback(async (dirPath: string = '') => {
    setLoading(true);
    try {
      const params = dirPath ? `?path=${encodeURIComponent(dirPath)}` : '';
      const res = await fetch(`/api/files/browse${params}`);
      if (res.ok) {
        const data = await res.json();
        setFiles(data.files || []);
        setCurrentPath(data.currentPath || '');
        setParentPath(data.parentPath || '');
      }
    } catch { /* silent */ } finally { setLoading(false); }
  }, []);

  useEffect(() => { loadDirectory(); }, [loadDirectory]);

  const navigateTo = (p: string) => { setSelectedFiles(new Set()); loadDirectory(p); };

  const toggleSelect = (filePath: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setSelectedFiles(prev => { const next = new Set(prev); if (next.has(filePath)) next.delete(filePath); else next.add(filePath); return next; });
  };

  const toggleSelectAll = () => {
    if (selectedFiles.size === files.length) setSelectedFiles(new Set());
    else setSelectedFiles(new Set(files.map(f => f.path)));
  };

  const handleFileClick = (file: BrowserFile) => {
    if (file.isDir) navigateTo(file.path);
  };

  const handleUpload = async (file: File) => {
    if (!file.name.endsWith('.zip')) { toast({ title: 'Invalid file', description: 'Only ZIP files are allowed', variant: 'destructive' }); return; }
    if (file.size > 10 * 1024 * 1024) { toast({ title: 'File too large', description: 'Maximum size is 10MB', variant: 'destructive' }); return; }

    setUploading(true);
    setUploadProgress(0);
    const formData = new FormData();
    formData.append('file', file);

    try {
      const xhr = new XMLHttpRequest();
      xhr.open('POST', '/api/files/upload');
      xhr.upload.onprogress = (e) => { if (e.lengthComputable) setUploadProgress(Math.round((e.loaded / e.total) * 100)); };
      xhr.onload = () => {
        if (xhr.status === 200) {
          const data = JSON.parse(xhr.responseText);
          if (data.file?.extracted) {
            toast({ title: 'Upload & Extracted', description: `${file.name} uploaded and extracted successfully` });
          } else {
            toast({ title: 'Upload Successful', description: `${file.name} uploaded` });
          }
          const extractDir = data.file?.extractDir;
          if (extractDir) {
            const folderName = extractDir.split('/').pop();
            loadDirectory(folderName || '');
          } else {
            loadDirectory(currentPath);
          }
        } else {
          try { const data = JSON.parse(xhr.responseText); toast({ title: 'Upload Failed', description: data.error, variant: 'destructive' }); }
          catch { toast({ title: 'Upload Failed', description: 'Unknown error', variant: 'destructive' }); }
        }
        setUploading(false); setUploadProgress(0);
      };
      xhr.onerror = () => { toast({ title: 'Upload Failed', description: 'Network error', variant: 'destructive' }); setUploading(false); setUploadProgress(0); };
      xhr.send(formData);
    } catch { toast({ title: 'Upload Failed', description: 'Unknown error', variant: 'destructive' }); setUploading(false); }
  };

  const handleCreateDir = async () => {
    if (!mkdirName.trim()) return;
    setOperationMsg('Creating directory...');
    try {
      const res = await fetch('/api/files/browse', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'mkdir', relativePath: currentPath, name: mkdirName.trim() }),
      });
      const data = await res.json();
      setOperationMsg(null);
      if (!res.ok) toast({ title: 'Failed', description: data.error, variant: 'destructive' });
      else { toast({ title: 'Created', description: data.message }); setShowMkdirModal(false); setMkdirName(''); loadDirectory(currentPath); }
    } catch { setOperationMsg(null); toast({ title: 'Error', description: 'Failed to create directory', variant: 'destructive' }); }
  };

  const handleCreateFile = async () => {
    if (!newFileName.trim()) return;
    setOperationMsg('Creating file...');
    try {
      const res = await fetch('/api/files/browse', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'touch', relativePath: currentPath, name: newFileName.trim() }),
      });
      const data = await res.json();
      setOperationMsg(null);
      if (!res.ok) toast({ title: 'Failed', description: data.error, variant: 'destructive' });
      else { toast({ title: 'Created', description: data.message }); setShowNewFileModal(false); setNewFileName(''); loadDirectory(currentPath); }
    } catch { setOperationMsg(null); toast({ title: 'Error', description: 'Failed to create file', variant: 'destructive' }); }
  };

  const handleDeleteSelected = async () => {
    const itemsToDelete = selectedFiles.size > 0 ? Array.from(selectedFiles) : (showContextFor ? [showContextFor.path] : []);
    if (itemsToDelete.length === 0) return;
    if (!confirm(`Delete ${itemsToDelete.length} item(s)? This cannot be undone.`)) return;
    setOperationMsg('Deleting...');
    try {
      const res = await fetch('/api/files/browse', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'delete', items: itemsToDelete }),
      });
      const data = await res.json();
      setOperationMsg(null);
      if (!res.ok) toast({ title: 'Delete Failed', description: data.error, variant: 'destructive' });
      else { toast({ title: 'Deleted', description: data.message }); setSelectedFiles(new Set()); setShowContextFor(null); loadDirectory(currentPath); }
    } catch { setOperationMsg(null); toast({ title: 'Error', description: 'Delete failed', variant: 'destructive' }); }
  };

  const handleRename = async () => {
    if (!renameNew.trim() || !renameOld) return;
    setOperationMsg('Renaming...');
    try {
      const res = await fetch('/api/files/browse', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'rename', relativePath: renameOld, name: renameNew.trim() }),
      });
      const data = await res.json();
      setOperationMsg(null);
      if (!res.ok) toast({ title: 'Rename Failed', description: data.error, variant: 'destructive' });
      else { toast({ title: 'Renamed', description: data.message }); setShowRenameModal(false); setShowContextFor(null); setRenameOld(''); setRenameNew(''); loadDirectory(currentPath); }
    } catch { setOperationMsg(null); toast({ title: 'Error', description: 'Rename failed', variant: 'destructive' }); }
  };

  const handleMove = async () => {
    const itemsToMove = selectedFiles.size > 0 ? Array.from(selectedFiles) : [];
    if (itemsToMove.length === 0) return;
    setOperationMsg('Moving...');
    try {
      const res = await fetch('/api/files/browse', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'move', relativePath: currentPath, items: itemsToMove, destination: moveDest }),
      });
      const data = await res.json();
      setOperationMsg(null);
      if (!res.ok) toast({ title: 'Move Failed', description: data.error, variant: 'destructive' });
      else {
        toast({ title: 'Moved', description: data.message });
        setShowMoveModal(false); setSelectedFiles(new Set()); setMoveDest(''); loadDirectory(currentPath);
      }
    } catch { setOperationMsg(null); toast({ title: 'Error', description: 'Move failed', variant: 'destructive' }); }
  };

  const openRenameModal = (file: BrowserFile) => {
    setShowContextFor(null);
    setRenameOld(file.path);
    setRenameNew(file.name);
    setShowRenameModal(true);
  };

  const openMoveModal = () => {
    setShowContextFor(null);
    setMoveDest('');
    setShowMoveModal(true);
  };

  const handleDrop = (e: React.DragEvent) => { e.preventDefault(); setDragOver(false); const file = e.dataTransfer.files[0]; if (file) handleUpload(file); };

  const pathSegments = currentPath ? currentPath.split('/') : [];
  const breadcrumbItems = [
    { label: '/home/container', path: '' },
    ...pathSegments.map((seg, i) => ({ label: seg, path: pathSegments.slice(0, i + 1).join('/') })),
  ];

  const subFolders = files.filter(f => f.isDir);

  return (
    <div className="flex flex-col h-full animate-fade-in relative">
      {/* Premium Action Bar */}
      <div className="fm-action-bar px-4 py-3 shrink-0 space-y-2.5">
        <div className="flex items-center gap-2 flex-wrap">
          <Button onClick={() => fileInputRef.current?.click()}
            className="bg-primary hover:bg-primary/90 text-primary-foreground h-8 px-4 text-xs rounded-lg btn-glow-blurple"
            disabled={uploading}>
            <Upload className="w-3.5 h-3.5 mr-1.5" /> Upload
          </Button>
          <Button onClick={() => setShowNewFileModal(true)}
            className="bg-primary/80 hover:bg-primary/90 text-primary-foreground h-8 px-3.5 text-xs rounded-lg">
            <FilePlus className="w-3.5 h-3.5 mr-1.5" /> New File
          </Button>
          <Button onClick={() => setShowMkdirModal(true)} variant="secondary" className="h-8 px-3.5 text-xs rounded-lg">
            <FolderPlus className="w-3.5 h-3.5 mr-1.5" /> New Folder
          </Button>
          {selectedFiles.size > 0 && (
            <>
              <div className="w-px h-5 bg-border/30 mx-1" />
              <Button onClick={openMoveModal} variant="secondary" className="h-8 px-3.5 text-xs rounded-lg">
                <Move className="w-3.5 h-3.5 mr-1.5" /> Move
              </Button>
              <Button onClick={handleDeleteSelected} variant="secondary"
                className="h-8 px-3.5 text-xs rounded-lg text-red-400 hover:text-red-300 hover:bg-red-500/10">
                <Trash2 className="w-3.5 h-3.5 mr-1.5" /> Delete
              </Button>
            </>
          )}
          <div className="ml-auto flex items-center gap-2">
            <span className="text-[10px] text-muted-foreground/40 font-mono">{files.length} item{files.length !== 1 ? 's' : ''}</span>
            <Button onClick={() => loadDirectory(currentPath)} variant="ghost"
              className="h-7 w-7 p-0 text-muted-foreground/40 hover:text-foreground/70 rounded-md">
              <RefreshCw className="w-3.5 h-3.5" />
            </Button>
          </div>
        </div>
        {uploading && (
          <div className="space-y-1.5 animate-fade-in">
            <Progress value={uploadProgress} className="h-1" />
            <p className="text-[10px] text-muted-foreground/50">Uploading... {uploadProgress}%</p>
          </div>
        )}
      </div>

      {/* Premium Breadcrumb */}
      <div className="fm-breadcrumb px-4 py-2 shrink-0">
        <div className="flex items-center gap-0.5 text-xs min-w-0 overflow-x-auto">
          {/* Select all checkbox */}
          <div className={`w-4 h-4 rounded-[3px] border flex items-center justify-center shrink-0 cursor-pointer mr-3 transition-all ${
            selectedFiles.size === files.length && files.length > 0 ? 'bg-primary border-primary text-primary-foreground' : 'border-muted-foreground/25 hover:border-primary/50'
          }`} onClick={toggleSelectAll}>
            {selectedFiles.size === files.length && files.length > 0 && (
              <svg className="w-2.5 h-2.5" viewBox="0 0 12 12" fill="none"><path d="M2.5 6L5 8.5L9.5 3.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
            )}
          </div>
          {currentPath && (
            <button onClick={() => navigateTo(parentPath)}
              className="flex items-center gap-1 shrink-0 px-1.5 py-0.5 rounded-md text-muted-foreground/50 hover:text-foreground/70 hover:bg-muted/30 transition-all">
              <ArrowLeft className="w-3 h-3" />
              <span>..</span>
            </button>
          )}
          {breadcrumbItems.map((crumb, i) => (
            <div key={i} className="flex items-center gap-0.5 shrink-0">
              {i > 0 && <ChevronRight className="w-2.5 h-2.5 text-muted-foreground/20" />}
              {i === breadcrumbItems.length - 1 ? (
                <span className="px-1.5 py-0.5 rounded-md text-foreground/80 font-medium">{crumb.label}</span>
              ) : (
                <button onClick={() => navigateTo(crumb.path)} className="px-1.5 py-0.5 rounded-md text-primary/60 hover:text-primary hover:bg-primary/5 transition-all">{crumb.label}</button>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Drag overlay */}
      <div className={`absolute inset-0 z-30 transition-all pointer-events-none ${dragOver ? 'bg-primary/5 border-2 border-dashed border-primary/40 rounded-xl m-2' : ''}`}
        onDragOver={(e) => { e.preventDefault(); e.stopPropagation(); setDragOver(true); }}
        onDragLeave={(e) => { e.preventDefault(); e.stopPropagation(); setDragOver(false); }}
        onDrop={(e) => { e.preventDefault(); e.stopPropagation(); handleDrop(e); }} />

      <input ref={fileInputRef} type="file" accept=".zip" className="hidden"
        onChange={(e) => { const file = e.target.files?.[0]; if (file) handleUpload(file); e.target.value = ''; }} />

      {/* File List */}
      <div className="flex-1 overflow-y-auto">
        {loading && !operationMsg ? (
          <div className="flex items-center justify-center py-20">
            <div className="relative"><Loader2 className="w-5 h-5 animate-spin text-muted-foreground/30" />
              <div className="absolute inset-0 rounded-full bg-primary/10 blur-md animate-pulse" /></div>
          </div>
        ) : operationMsg ? (
          <div className="flex flex-col items-center justify-center py-20 gap-3">
            <div className="relative"><Loader2 className="w-5 h-5 animate-spin text-primary" />
              <div className="absolute inset-0 rounded-full bg-primary/20 blur-md animate-pulse" /></div>
            <p className="text-xs text-muted-foreground/60 font-medium">{operationMsg}</p>
          </div>
        ) : files.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-muted-foreground/30 animate-fade-in">
            <div className="w-16 h-16 rounded-2xl bg-muted/10 flex items-center justify-center mb-4 border border-border/10">
              <FolderOpen className="w-7 h-7 opacity-40" />
            </div>
            <p className="text-sm font-medium text-muted-foreground/40">Empty directory</p>
            <p className="text-[11px] mt-1.5 text-muted-foreground/25">Drop a ZIP file or create new files</p>
          </div>
        ) : (
          <div className="divide-y divide-border/8">
            {files.map((file, idx) => (
              <div key={file.path} onClick={() => handleFileClick(file)}
                className={`fm-row flex items-center gap-3 px-4 py-2 group animate-fade-in-up ${selectedFiles.has(file.path) ? 'fm-row-selected' : ''} ${file.isDir ? 'cursor-pointer' : ''}`}
                style={{ animationDelay: `${Math.min(idx * 0.015, 0.25)}s` }}>
                {/* Checkbox */}
                <div onClick={(e) => toggleSelect(file.path, e)}
                  className={`w-3.5 h-3.5 rounded-[2.5px] border flex items-center justify-center shrink-0 cursor-pointer transition-all ${
                    selectedFiles.has(file.path) ? 'bg-primary border-primary text-primary-foreground' : 'border-muted-foreground/15 group-hover:border-muted-foreground/35'
                  }`}>
                  {selectedFiles.has(file.path) && <svg className="w-2.5 h-2.5" viewBox="0 0 12 12" fill="none"><path d="M2.5 6L5 8.5L9.5 3.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>}
                </div>
                {/* Icon */}
                <div className={`fm-row-icon w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                  file.isDir ? 'bg-yellow-400/10' :
                  file.name.endsWith('.zip') ? 'bg-orange-400/10' :
                  file.name.endsWith('.js') || file.name.endsWith('.ts') ? 'bg-cyan-400/8' :
                  file.name.endsWith('.json') ? 'bg-green-400/8' :
                  file.name.endsWith('.py') ? 'bg-blue-400/8' :
                  file.name.endsWith('.env') ? 'bg-red-400/8' :
                  'bg-muted/20'
                }`}>
                  {file.isDir ? <Folder className="w-4 h-4 text-yellow-400/80" /> :
                   file.name.endsWith('.zip') ? <FileArchive className="w-4 h-4 text-orange-400/80" /> :
                   file.name.endsWith('.js') ? <FileText className="w-4 h-4 text-cyan-400/70" /> :
                   file.name.endsWith('.ts') ? <FileText className="w-4 h-4 text-blue-400/70" /> :
                   file.name.endsWith('.json') ? <FileText className="w-4 h-4 text-green-400/70" /> :
                   file.name.endsWith('.py') ? <FileText className="w-4 h-4 text-yellow-300/70" /> :
                   file.name.endsWith('.env') ? <Shield className="w-4 h-4 text-red-400/60" /> :
                   <File className="w-4 h-4 text-muted-foreground/40" />}
                </div>
                {/* Name + info */}
                <div className="flex-1 min-w-0">
                  <p className={`fm-row-name text-[13px] truncate ${selectedFiles.has(file.path) ? 'text-foreground' : 'text-foreground/75'}`}>
                    {file.name}
                  </p>
                  {!file.isDir && (
                    <p className="text-[10px] text-muted-foreground/25 font-mono mt-px">
                      {formatBytes(file.size)} &middot; {new Date(file.modified).toLocaleDateString()}
                    </p>
                  )}
                  {file.isDir && (
                    <p className="text-[10px] text-muted-foreground/25 mt-px">Folder</p>
                  )}
                </div>
                {/* Context menu trigger */}
                <button onClick={(e) => { e.stopPropagation(); setShowContextFor(showContextFor?.path === file.path ? null : file); }}
                  className={`w-7 h-7 flex items-center justify-center rounded-md transition-all shrink-0 ${
                    showContextFor?.path === file.path ? 'bg-muted/50 text-foreground/60' : 'opacity-0 group-hover:opacity-100 hover:bg-muted/30 text-muted-foreground/30'
                  }`}>
                  <MoreVertical className="w-3.5 h-3.5" />
                </button>
                {/* Context dropdown */}
                {showContextFor?.path === file.path && (
                  <div className="absolute right-4 z-40 fm-context-menu p-1 min-w-[140px] animate-scale-in" onClick={(e) => e.stopPropagation()}>
                    <button onClick={() => openRenameModal(file)}
                      className="w-full flex items-center gap-2 px-2.5 py-1.5 text-xs text-foreground/70 hover:text-foreground hover:bg-muted/30 rounded-md transition-all">
                      <FileText className="w-3.5 h-3.5" /> Rename
                    </button>
                    <button onClick={() => { setSelectedFiles(new Set([file.path])); setShowContextFor(null); openMoveModal(); }}
                      className="w-full flex items-center gap-2 px-2.5 py-1.5 text-xs text-foreground/70 hover:text-foreground hover:bg-muted/30 rounded-md transition-all">
                      <Move className="w-3.5 h-3.5" /> Move
                    </button>
                    <div className="h-px bg-border/20 my-1" />
                    <button onClick={() => handleDeleteSelected()}
                      className="w-full flex items-center gap-2 px-2.5 py-1.5 text-xs text-red-400/80 hover:text-red-400 hover:bg-red-500/10 rounded-md transition-all">
                      <Trash2 className="w-3.5 h-3.5" /> Delete
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Selection bar */}
      {selectedFiles.size > 0 && !showMoveModal && !showRenameModal && (
        <div className="fm-selection-bar px-4 py-2.5 animate-fade-in-up shrink-0">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span className="text-[11px] text-muted-foreground/50 font-medium">{selectedFiles.size} selected</span>
              <div className="flex items-center gap-1.5">
                <Button onClick={openMoveModal} variant="secondary" size="sm" className="h-7 px-3 text-[11px] rounded-md">
                  <Move className="w-3 h-3 mr-1" /> Move
                </Button>
                <Button onClick={handleDeleteSelected} variant="ghost" size="sm"
                  className="h-7 px-3 text-[11px] text-red-400/70 hover:text-red-400 rounded-md">
                  <Trash2 className="w-3 h-3 mr-1" /> Delete
                </Button>
              </div>
            </div>
            <Button variant="ghost" size="sm" className="h-7 px-2 text-[11px] text-muted-foreground/30 hover:text-foreground/60 rounded-md"
              onClick={() => setSelectedFiles(new Set())}>
              <X className="w-3 h-3" />
            </Button>
          </div>
        </div>
      )}

      {/* ========== MODALS ========== */}

      {/* Move Modal */}
      {showMoveModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center premium-overlay animate-fade-in" onClick={() => setShowMoveModal(false)}>
          <div className="premium-modal w-full max-w-md mx-4 animate-scale-in" onClick={e => e.stopPropagation()}>
            {/* Header */}
            <div className="flex items-center gap-3 p-5 pb-0">
              <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center border border-primary/15">
                <Move className="w-5 h-5 text-primary" />
              </div>
              <div className="flex-1">
                <h3 className="text-sm font-semibold text-foreground/90">Move {selectedFiles.size} Item(s)</h3>
                <p className="text-[11px] text-muted-foreground/40 mt-0.5">Choose a destination folder</p>
              </div>
              <button onClick={() => setShowMoveModal(false)} className="w-7 h-7 flex items-center justify-center rounded-md hover:bg-muted/30 text-muted-foreground/40 hover:text-foreground/60 transition-all">
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Current location */}
            <div className="px-5 pt-4 pb-2">
              <p className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground/35 mb-2">Current Location</p>
              <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-muted/15 border border-border/15">
                <FolderOpen className="w-3.5 h-3.5 text-muted-foreground/30" />
                <span className="text-xs text-muted-foreground/50 font-mono">{currentPath || '/home/container'}</span>
              </div>
            </div>

            {/* Destination input */}
            <div className="px-5 pb-3">
              <p className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground/35 mb-2">Destination Path</p>
              <Input value={moveDest} onChange={(e) => setMoveDest(e.target.value)}
                placeholder="e.g. my-folder, ../subfolder"
                className="premium-input bg-background/40 border-border/30 h-9 text-xs font-mono rounded-lg" />
            </div>

            {/* Quick picks */}
            <div className="px-5 pb-3">
              <p className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground/35 mb-2">Quick Move</p>
              <div className="flex flex-wrap gap-1.5">
                <button onClick={() => setMoveDest('/')}
                  className={`px-2.5 py-1.5 rounded-md text-[11px] transition-all ${
                    moveDest === '/' ? 'bg-primary/15 text-primary border border-primary/25' : 'bg-muted/15 text-muted-foreground/50 border border-border/15 hover:bg-muted/25 hover:text-foreground/70'
                  }`}>
                  <Home className="w-3 h-3 mr-1 inline" /> Root
                </button>
                {currentPath && (
                  <button onClick={() => setMoveDest('..')}
                    className={`px-2.5 py-1.5 rounded-md text-[11px] transition-all ${
                      moveDest === '..' ? 'bg-primary/15 text-primary border border-primary/25' : 'bg-muted/15 text-muted-foreground/50 border border-border/15 hover:bg-muted/25 hover:text-foreground/70'
                    }`}>
                    <ArrowLeft className="w-3 h-3 mr-1 inline" /> ../
                  </button>
                )}
                {subFolders.map(folder => (
                  <button key={folder.path} onClick={() => setMoveDest(folder.name)}
                    disabled={selectedFiles.has(folder.path)}
                    className={`px-2.5 py-1.5 rounded-md text-[11px] transition-all disabled:opacity-30 ${
                      moveDest === folder.name ? 'bg-primary/15 text-primary border border-primary/25' : 'bg-muted/15 text-muted-foreground/50 border border-border/15 hover:bg-muted/25 hover:text-foreground/70'
                    }`}>
                    <Folder className="w-3 h-3 mr-1 inline text-yellow-400/60" /> {folder.name}
                  </button>
                ))}
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center justify-end gap-2 p-5 pt-2 border-t border-border/15">
              <Button variant="ghost" className="h-8 text-xs rounded-lg text-muted-foreground/50" onClick={() => setShowMoveModal(false)}>Cancel</Button>
              <Button className="h-8 text-xs rounded-lg bg-primary hover:bg-primary/90 btn-glow-blurple"
                onClick={handleMove} disabled={selectedFiles.size === 0}>
                <Move className="w-3.5 h-3.5 mr-1.5" /> Move Here
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Rename Modal */}
      {showRenameModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center premium-overlay animate-fade-in" onClick={() => setShowRenameModal(false)}>
          <div className="premium-modal w-full max-w-sm mx-4 p-5 space-y-4 animate-scale-in" onClick={e => e.stopPropagation()}>
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center border border-primary/15">
                <FileText className="w-4 h-4 text-primary" />
              </div>
              <div>
                <h3 className="text-sm font-semibold text-foreground/90">Rename</h3>
                <p className="text-[10px] text-muted-foreground/40 font-mono">{renameOld}</p>
              </div>
            </div>
            <Input value={renameNew} onChange={(e) => setRenameNew(e.target.value)} placeholder="New name"
              className="premium-input bg-background/50 border-border/30 text-sm" autoFocus
              onKeyDown={(e) => e.key === 'Enter' && handleRename()} />
            <div className="flex justify-end gap-2 pt-1">
              <Button variant="ghost" className="h-8 text-xs rounded-lg" onClick={() => setShowRenameModal(false)}>Cancel</Button>
              <Button className="h-8 text-xs bg-primary hover:bg-primary/90 rounded-lg btn-glow-blurple"
                onClick={handleRename} disabled={!renameNew.trim() || renameNew === renameOld.split('/').pop()}>
                Rename
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* New Folder Modal */}
      {showMkdirModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center premium-overlay animate-fade-in" onClick={() => setShowMkdirModal(false)}>
          <div className="premium-modal w-full max-w-sm mx-4 p-5 space-y-4 animate-scale-in" onClick={e => e.stopPropagation()}>
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-yellow-400/10 flex items-center justify-center border border-yellow-400/15">
                <FolderPlus className="w-4 h-4 text-yellow-400" />
              </div>
              <h3 className="text-sm font-semibold text-foreground/90">Create Folder</h3>
            </div>
            <Input value={mkdirName} onChange={(e) => setMkdirName(e.target.value)} placeholder="Folder name"
              className="premium-input bg-background/50 border-border/30" autoFocus onKeyDown={(e) => e.key === 'Enter' && handleCreateDir()} />
            <div className="flex justify-end gap-2">
              <Button variant="ghost" className="h-8 text-xs rounded-lg" onClick={() => setShowMkdirModal(false)}>Cancel</Button>
              <Button className="h-8 text-xs bg-primary hover:bg-primary/90 rounded-lg btn-glow-blurple" onClick={handleCreateDir} disabled={!mkdirName.trim()}>Create</Button>
            </div>
          </div>
        </div>
      )}

      {/* New File Modal */}
      {showNewFileModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center premium-overlay animate-fade-in" onClick={() => setShowNewFileModal(false)}>
          <div className="premium-modal w-full max-w-sm mx-4 p-5 space-y-4 animate-scale-in" onClick={e => e.stopPropagation()}>
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-cyan-400/10 flex items-center justify-center border border-cyan-400/15">
                <FilePlus className="w-4 h-4 text-cyan-400" />
              </div>
              <h3 className="text-sm font-semibold text-foreground/90">New File</h3>
            </div>
            <Input value={newFileName} onChange={(e) => setNewFileName(e.target.value)} placeholder="e.g. bot.js, config.json"
              className="premium-input bg-background/50 border-border/30" autoFocus onKeyDown={(e) => e.key === 'Enter' && handleCreateFile()} />
            <div className="flex justify-end gap-2">
              <Button variant="ghost" className="h-8 text-xs rounded-lg" onClick={() => setShowNewFileModal(false)}>Cancel</Button>
              <Button className="h-8 text-xs bg-primary hover:bg-primary/90 rounded-lg btn-glow-blurple" onClick={handleCreateFile} disabled={!newFileName.trim()}>Create</Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ============================================================
// DEPLOY TAB
// ============================================================
function DeployTab({ userId }: { userId: string }) {
  const [files, setFiles] = useState<FileEntry[]>([]);
  const [deployInfo, setDeployInfo] = useState<DeployInfo | null>(null);
  const [loading, setLoading] = useState(true);
  const [deploying, setDeploying] = useState(false);
  const [selectedDir, setSelectedDir] = useState<string | null>(null);
  const [customEntry, setCustomEntry] = useState('');
  const { toast } = useToast();

  const loadData = useCallback(async () => {
    try {
      const [filesRes, statusRes] = await Promise.all([fetch('/api/files/list'), fetch('/api/deploy/status')]);
      if (filesRes.ok) {
        const data = await filesRes.json();
        setFiles(data.files);
        const extracted = data.files.find((f: FileEntry) => f.extracted && f.extractDir);
        if (extracted && !selectedDir) setSelectedDir(extracted.extractDir);
      }
      if (statusRes.ok) setDeployInfo(await statusRes.json());
    } catch { /* silent */ } finally { setLoading(false); }
  }, [selectedDir]);

  useEffect(() => { loadData(); }, [loadData]);

  const handleDeploy = async () => {
    if (!selectedDir) { toast({ title: 'No directory selected', description: 'Upload and extract a ZIP file first', variant: 'destructive' }); return; }
    setDeploying(true);
    try {
      const body: any = { extractDir: selectedDir };
      if (customEntry.trim()) body.entryPoint = customEntry.trim();
      const res = await fetch('/api/deploy/start', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
      const data = await res.json();
      if (!res.ok) toast({ title: 'Deploy Failed', description: data.error, variant: 'destructive' });
      else toast({ title: 'Deployed!', description: `PID: ${data.pid}` });
    } catch { toast({ title: 'Error', description: 'Deployment failed', variant: 'destructive' }); }
    finally { setDeploying(false); loadData(); }
  };

  const handleStop = async () => {
    try { await fetch('/api/deploy/stop', { method: 'POST' }); toast({ title: 'Stopped', description: 'Process stopped' }); loadData(); }
    catch { toast({ title: 'Error', description: 'Failed to stop', variant: 'destructive' }); }
  };

  const handleRestart = async () => {
    try { await fetch('/api/deploy/restart', { method: 'POST' }); toast({ title: 'Restarted', description: 'Process restarted' }); loadData(); }
    catch { toast({ title: 'Error', description: 'Failed to restart', variant: 'destructive' }); }
  };

  if (loading) {
    return <div className="flex-1 flex items-center justify-center">
      <div className="relative"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground/40" />
        <div className="absolute inset-0 rounded-full bg-primary/10 blur-md animate-pulse" /></div>
    </div>;
  }

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-4">
      {/* Deploy Card */}
      <Card className={`premium-card gradient-border-blurple ${deploying ? 'deploy-card-pulse' : ''} animate-card-enter`}>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-semibold flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
              <Rocket className={`w-4 h-4 text-primary ${deploying ? 'animate-rocket-launch' : ''}`} />
            </div>
            Deploy Bot
            {deploying && (
              <span className="flex items-center gap-1 ml-2">
                <span className="w-1.5 h-1.5 rounded-full bg-primary/60 animate-typing-dots" />
                <span className="w-1.5 h-1.5 rounded-full bg-primary/60 animate-typing-dots" style={{ animationDelay: '0.2s' }} />
                <span className="w-1.5 h-1.5 rounded-full bg-primary/60 animate-typing-dots" style={{ animationDelay: '0.4s' }} />
              </span>
            )}
          </CardTitle>
          <CardDescription className="text-xs text-muted-foreground/50 ml-[42px]">Select an extracted project directory and deploy</CardDescription>
        </CardHeader>
        <CardContent className="p-4 pt-0 space-y-4">
          <div className="space-y-2">
            <label className="text-xs font-semibold text-muted-foreground/50 uppercase tracking-wider">Project Directory</label>
            {files.filter(f => f.extracted && f.extractDir).length === 0 ? (
              <div className="flex items-center gap-2.5 p-3.5 rounded-xl bg-muted/20 border border-border/20 text-sm text-muted-foreground/50">
                <Info className="w-4 h-4 shrink-0 text-primary/50" />
                No extracted projects. Go to File Manager to upload and extract a ZIP file.
              </div>
            ) : (
              <select value={selectedDir || ''} onChange={(e) => setSelectedDir(e.target.value || null)}
                className="w-full bg-background/50 border border-border/40 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-1 focus:ring-primary/50 focus:border-primary/40 transition-all">
                <option value="">Select a project...</option>
                {files.filter(f => f.extracted && f.extractDir).map(f => (
                  <option key={f.id} value={f.extractDir || ''}>{f.fileName}</option>
                ))}
              </select>
            )}
          </div>
          <div className="space-y-2">
            <label className="text-xs font-semibold text-muted-foreground/50 uppercase tracking-wider">Entry Point</label>
            <Input value={customEntry} onChange={(e) => setCustomEntry(e.target.value)}
              placeholder="e.g., bot.js, main.py (auto-detected)"
              className="premium-input bg-background/50 border-border/40 text-sm rounded-xl" />
          </div>
          <div className="flex items-center gap-2 pt-1">
            <Button onClick={handleDeploy} disabled={deploying || !selectedDir || deployInfo?.running}
              className="bg-primary hover:bg-primary/90 text-primary-foreground text-sm rounded-xl btn-glow-blurple">
              {deploying ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Play className="w-4 h-4 mr-2" />}
              Deploy
            </Button>
            {deployInfo?.running && (
              <>
                <Button onClick={handleRestart} variant="secondary" className="text-sm rounded-xl">
                  <RotateCcw className="w-4 h-4 mr-2" /> Restart
                </Button>
                <Button onClick={handleStop} className="bg-red-600/80 hover:bg-red-600 text-white text-sm rounded-xl">
                  <Square className="w-4 h-4 mr-2" /> Stop
                </Button>
              </>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Process Status */}
      <Card className="premium-card animate-card-enter stagger-2">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-semibold flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
              <Activity className="w-4 h-4 text-primary" />
            </div>
            Process Status
          </CardTitle>
        </CardHeader>
        <CardContent className="p-4 pt-0">
          {deployInfo?.running || deployInfo?.status === 'stopped' ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
              {[
                { label: 'Status', value: <div className="flex items-center gap-1.5"><div className="relative"><div className={`w-2 h-2 rounded-full ${deployInfo.running ? 'bg-green-500' : 'bg-red-500'}`} />{deployInfo.running && <div className="absolute inset-0 w-2 h-2 rounded-full bg-green-500 animate-breathing" />}</div><span className="text-sm font-mono capitalize">{deployInfo.status}</span></div> },
                { label: 'PID', value: <p className="text-sm font-mono">{deployInfo.pid || 'N/A'}</p> },
                { label: 'Entry Point', value: <p className="text-sm font-mono">{deployInfo.entryPoint || 'N/A'}</p> },
                { label: 'Uptime', value: <p className="text-sm font-mono">{deployInfo.running ? formatUptime(deployInfo.uptime / 1000) : 'N/A'}</p> },
                { label: 'Log Lines', value: <p className="text-sm font-mono">{deployInfo.logCount}</p> },
                { label: 'Working Dir', value: <p className="text-xs font-mono truncate">{deployInfo.workingDir || 'N/A'}</p> },
              ].map((item, i) => (
                <div key={i} className={`premium-stat p-3 animate-fade-in-up stagger-${i + 1}`}>
                  <p className="text-[10px] text-muted-foreground/50 font-semibold uppercase tracking-wider mb-1.5">{item.label}</p>
                  {item.value}
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-10 text-muted-foreground/40 animate-fade-in">
              <div className="w-12 h-12 rounded-xl bg-muted/20 flex items-center justify-center mx-auto mb-3"><Activity className="w-6 h-6 opacity-40" /></div>
              <p className="text-sm text-muted-foreground/50">No process deployed</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

// ============================================================
// SETTINGS TAB
// ============================================================
function SettingsTab({ user }: { user: UserInfo }) {
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [changing, setChanging] = useState(false);
  const { toast } = useToast();

  const handleChangePassword = async () => {
    if (!newPassword || !confirmPassword) { toast({ title: 'Error', description: 'Please fill in both fields', variant: 'destructive' }); return; }
    if (newPassword !== confirmPassword) { toast({ title: 'Error', description: 'Passwords do not match', variant: 'destructive' }); return; }
    if (newPassword.length < 6) { toast({ title: 'Error', description: 'Password must be at least 6 characters', variant: 'destructive' }); return; }
    setChanging(true);
    try {
      const res = await fetch('/api/auth/change-password', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ newPassword }) });
      if (res.ok) { toast({ title: 'Password Changed', description: 'Your password has been updated' }); setNewPassword(''); setConfirmPassword(''); }
      else toast({ title: 'Error', description: 'Failed to change password', variant: 'destructive' });
    } catch { toast({ title: 'Error', description: 'Network error', variant: 'destructive' }); }
    finally { setChanging(false); }
  };

  const planColor = user.plan === 'premium' ? 'text-yellow-400 border-yellow-400/20 bg-yellow-400/5' :
    user.plan === 'admin' ? 'text-red-400 border-red-400/20 bg-red-400/5' : 'text-green-400 border-green-400/20 bg-green-400/5';

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-4">
      {/* Account Info */}
      <Card className="premium-card gradient-border animate-card-enter">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-semibold flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
              <User className="w-4 h-4 text-primary" />
            </div>
            Account Information
          </CardTitle>
        </CardHeader>
        <CardContent className="p-4 pt-0 space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            <div className="premium-stat p-3 animate-fade-in-up stagger-1">
              <p className="text-[10px] text-muted-foreground/50 font-semibold uppercase tracking-wider mb-1.5">Username</p>
              <p className="text-sm font-mono font-medium text-foreground/90">{user.username}</p>
            </div>
            <div className="premium-stat p-3 animate-fade-in-up stagger-2">
              <p className="text-[10px] text-muted-foreground/50 font-semibold uppercase tracking-wider mb-1.5">Plan</p>
              <Badge variant="outline" className={`text-xs ${planColor} rounded-md`}><Shield className="w-3 h-3 mr-1" />{user.plan.toUpperCase()}</Badge>
            </div>
            <div className="premium-stat p-3 animate-fade-in-up stagger-3">
              <p className="text-[10px] text-muted-foreground/50 font-semibold uppercase tracking-wider mb-1.5">Status</p>
              <Badge variant="outline" className="text-xs text-green-400 border-green-400/20 bg-green-400/5 rounded-md"><CheckCircle2 className="w-3 h-3 mr-1" />{user.status.toUpperCase()}</Badge>
            </div>
            <div className="premium-stat p-3 animate-fade-in-up stagger-4">
              <p className="text-[10px] text-muted-foreground/50 font-semibold uppercase tracking-wider mb-1.5">User ID</p>
              <p className="text-xs font-mono truncate text-muted-foreground/60">{user.id}</p>
            </div>
          </div>
          <div className="my-3 h-px bg-gradient-to-r from-transparent via-border/30 to-transparent" />
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            <div className="premium-stat p-3 animate-fade-in-up stagger-5">
              <div className="flex items-center gap-1.5 mb-1.5"><Calendar className="w-3 h-3 text-muted-foreground/30" />
                <p className="text-[10px] text-muted-foreground/50 font-semibold uppercase tracking-wider">Activated</p></div>
              <p className="text-xs font-mono text-foreground/80">{user.activatedAt ? new Date(user.activatedAt).toLocaleString() : 'N/A'}</p>
            </div>
            <div className="premium-stat p-3 animate-fade-in-up stagger-6">
              <div className="flex items-center gap-1.5 mb-1.5"><Calendar className="w-3 h-3 text-muted-foreground/30" />
                <p className="text-[10px] text-muted-foreground/50 font-semibold uppercase tracking-wider">Expires</p></div>
              <p className="text-xs font-mono text-foreground/80">{user.expiresAt ? new Date(user.expiresAt).toLocaleString() : 'Never'}</p>
              {user.expiresAt && new Date(user.expiresAt) < new Date() && <p className="text-xs text-red-400 mt-1 font-medium">Expired</p>}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Change Password */}
      <Card className="premium-card animate-card-enter stagger-2">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-semibold flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
              <Shield className="w-4 h-4 text-primary" />
            </div>
            Change Password
          </CardTitle>
        </CardHeader>
        <CardContent className="p-4 pt-0 space-y-3">
          <div className="space-y-2">
            <label className="text-xs font-semibold text-muted-foreground/50 uppercase tracking-wider">New Password</label>
            <Input type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)}
              placeholder="Enter new password" className="premium-input bg-background/50 border-border/40 rounded-xl" />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-semibold text-muted-foreground/50 uppercase tracking-wider">Confirm Password</label>
            <Input type="password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)}
              placeholder="Confirm new password" className="premium-input bg-background/50 border-border/40 rounded-xl" />
          </div>
          <Button onClick={handleChangePassword} disabled={changing || !newPassword || !confirmPassword}
            className="bg-primary hover:bg-primary/90 text-primary-foreground text-sm rounded-xl btn-glow-blurple">
            {changing ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
            Update Password
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
