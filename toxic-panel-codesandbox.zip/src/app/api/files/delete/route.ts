import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import fs from 'fs';
import path from 'path';

const UPLOAD_DIR = '/home/z/my-project/uploads';

export async function DELETE(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });
    }

    const { filePath, extractDir } = await request.json();

    const userDir = path.join(UPLOAD_DIR, user.id);

    // Delete the zip file
    if (filePath) {
      const resolvedPath = path.resolve(filePath);
      if (!resolvedPath.startsWith(userDir)) {
        return NextResponse.json({ error: 'Access denied' }, { status: 403 });
      }
      if (fs.existsSync(resolvedPath)) {
        fs.unlinkSync(resolvedPath);
      }
    }

    // Delete extracted directory
    if (extractDir) {
      const resolvedExtract = path.resolve(extractDir);
      if (!resolvedExtract.startsWith(userDir)) {
        return NextResponse.json({ error: 'Access denied' }, { status: 403 });
      }
      if (fs.existsSync(resolvedExtract)) {
        fs.rmSync(resolvedExtract, { recursive: true, force: true });
      }
    }

    return NextResponse.json({ success: true, message: 'File deleted' });
  } catch (error: any) {
    return NextResponse.json({ error: 'Failed to delete file: ' + (error.message || 'Unknown error') }, { status: 500 });
  }
}
