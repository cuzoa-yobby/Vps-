import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { extractZip } from '@/lib/deploy';
import path from 'path';
import fs from 'fs';

const UPLOAD_DIR = '/home/z/my-project/uploads';

export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });
    }

    const { zipPath, extractTo } = await request.json();

    if (!zipPath) {
      return NextResponse.json({ error: 'zipPath is required' }, { status: 400 });
    }

    // Security check: path must be within user's directory
    const userDir = path.join(UPLOAD_DIR, user.id);
    const resolvedZipPath = path.resolve(zipPath);
    if (!resolvedZipPath.startsWith(userDir)) {
      return NextResponse.json({ error: 'Access denied' }, { status: 403 });
    }

    if (!fs.existsSync(resolvedZipPath)) {
      return NextResponse.json({ error: 'ZIP file not found' }, { status: 404 });
    }

    // Determine extract directory
    let targetDir = extractTo;
    if (!targetDir) {
      // Default: extract next to the zip file, replacing .zip extension
      targetDir = resolvedZipPath.replace(/\.zip$/i, '');
    } else {
      targetDir = path.resolve(targetDir);
      if (!targetDir.startsWith(userDir)) {
        return NextResponse.json({ error: 'Access denied' }, { status: 403 });
      }
    }

    // Check if already extracted
    if (fs.existsSync(targetDir) && fs.readdirSync(targetDir).length > 0) {
      // Re-extract (overwrite)
    }

    const result = extractZip(resolvedZipPath, targetDir);

    if (!result.success) {
      return NextResponse.json({ error: result.message }, { status: 500 });
    }

    return NextResponse.json({
      success: true,
      message: result.message,
      extractDir: targetDir,
      fileCount: result.files?.length || 0,
      files: result.files,
    });
  } catch (error: any) {
    return NextResponse.json({ error: 'Extraction failed: ' + (error.message || 'Unknown error') }, { status: 500 });
  }
}
