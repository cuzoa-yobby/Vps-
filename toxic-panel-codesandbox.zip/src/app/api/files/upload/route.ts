import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { extractZip } from '@/lib/deploy';
import path from 'path';
import fs from 'fs';

const UPLOAD_DIR = '/home/z/my-project/uploads';

export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });
    }

    const formData = await request.formData();
    const file = formData.get('file') as File | null;

    if (!file) {
      return NextResponse.json({ error: 'No file provided' }, { status: 400 });
    }

    if (!file.name.endsWith('.zip')) {
      return NextResponse.json({ error: 'Only ZIP files are allowed' }, { status: 400 });
    }

    if (file.size > 10 * 1024 * 1024) {
      return NextResponse.json({ error: 'File too large. Maximum 10MB' }, { status: 400 });
    }

    const userDir = path.join(UPLOAD_DIR, user.id);
    if (!fs.existsSync(userDir)) {
      fs.mkdirSync(userDir, { recursive: true });
    }

    // Save the uploaded ZIP file
    const zipPath = path.join(userDir, file.name);
    const bytes = Buffer.from(await file.arrayBuffer());
    fs.writeFileSync(zipPath, bytes);

    // Auto-extract the ZIP
    const extractDir = zipPath.replace(/\.zip$/i, '');
    const result = extractZip(zipPath, extractDir);

    return NextResponse.json({
      success: true,
      file: {
        fileName: file.name,
        filePath: zipPath,
        fileSize: file.size,
        extracted: result.success,
        extractDir: result.success ? extractDir : null,
        fileCount: result.files?.length || 0,
        files: result.files,
      },
      message: result.success
        ? `Uploaded and extracted ${result.files?.length || 0} files`
        : 'Uploaded but extraction failed',
    });
  } catch (error: any) {
    return NextResponse.json(
      { error: 'Upload failed: ' + (error.message || 'Unknown error') },
      { status: 500 }
    );
  }
}
