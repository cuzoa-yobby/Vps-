import { NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import path from 'path';
import fs from 'fs';

const UPLOAD_DIR = '/home/z/my-project/uploads';

export async function GET() {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });
    }

    const userDir = path.join(UPLOAD_DIR, user.id);
    if (!fs.existsSync(userDir)) {
      return NextResponse.json({ files: [] });
    }

    const entries = fs.readdirSync(userDir, { withFileTypes: true });
    const files: Array<{
      id: string;
      fileName: string;
      filePath: string;
      fileSize: number;
      extracted: boolean;
      extractDir: string | null;
      files: Array<{ name: string; isDir: boolean; size: number; modified: string }>;
      createdAt: string;
    }> = [];

    for (const entry of entries) {
      try {
        const fullPath = path.join(userDir, entry.name);
        const stat = fs.statSync(fullPath);

        if (entry.isFile() && entry.name.endsWith('.zip')) {
          // Check if there's a corresponding extracted folder
          const folderName = entry.name.replace(/\.zip$/i, '');
          const extractDir = path.join(userDir, folderName);
          const isExtracted = fs.existsSync(extractDir) && fs.statSync(extractDir).isDirectory();

          let extractedFiles: Array<{ name: string; isDir: boolean; size: number; modified: string }> = [];
          if (isExtracted) {
            const subEntries = fs.readdirSync(extractDir, { withFileTypes: true });
            extractedFiles = subEntries
              .map(se => {
                try {
                  const subStat = fs.statSync(path.join(extractDir, se.name));
                  return {
                    name: se.name,
                    isDir: se.isDirectory(),
                    size: se.isDirectory() ? 0 : subStat.size,
                    modified: subStat.mtime.toISOString(),
                  };
                } catch {
                  return null;
                }
              })
              .filter(Boolean) as any[];
          }

          files.push({
            id: entry.name,
            fileName: entry.name,
            filePath: fullPath,
            fileSize: stat.size,
            extracted: isExtracted,
            extractDir: isExtracted ? extractDir : null,
            files: extractedFiles,
            createdAt: stat.mtime.toISOString(),
          });
        } else if (entry.isDirectory()) {
          // Also list standalone directories (not from zip extraction)
          const subEntries = fs.readdirSync(fullPath, { withFileTypes: true });
          const dirFiles = subEntries
            .map(se => {
              try {
                const subStat = fs.statSync(path.join(fullPath, se.name));
                return {
                  name: se.name,
                  isDir: se.isDirectory(),
                  size: se.isDirectory() ? 0 : subStat.size,
                  modified: subStat.mtime.toISOString(),
                };
              } catch {
                return null;
              }
            })
            .filter(Boolean) as any[];

          files.push({
            id: entry.name,
            fileName: entry.name,
            filePath: fullPath,
            fileSize: 0,
            extracted: true,
            extractDir: fullPath,
            files: dirFiles,
            createdAt: stat.mtime.toISOString(),
          });
        }
      } catch {
        // Skip problematic entries
      }
    }

    // Sort by date descending
    files.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    return NextResponse.json({ files });
  } catch (error: any) {
    return NextResponse.json({ error: 'Failed to list files' }, { status: 500 });
  }
}
