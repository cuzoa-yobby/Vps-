import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import fs from 'fs';
import path from 'path';

const BASE_DIR = '/home/z/my-project/uploads';

function getUserBaseDir(userId: string): string {
  return path.join(BASE_DIR, userId);
}

export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const relativePath = searchParams.get('path') || '';

    const userBase = getUserBaseDir(user.id);
    const targetDir = relativePath
      ? path.resolve(userBase, relativePath)
      : userBase;

    // Security check: must be within user's directory
    if (!targetDir.startsWith(userBase)) {
      return NextResponse.json({ error: 'Access denied' }, { status: 403 });
    }

    if (!fs.existsSync(targetDir)) {
      fs.mkdirSync(targetDir, { recursive: true });
    }

    const stat = fs.statSync(targetDir);
    if (!stat.isDirectory()) {
      return NextResponse.json({ error: 'Not a directory' }, { status: 400 });
    }

    const entries = fs.readdirSync(targetDir, { withFileTypes: true });

    const files = entries
      .map(entry => {
        try {
          const fullPath = path.join(targetDir, entry.name);
          const fileStat = fs.statSync(fullPath);
          const isDir = entry.isDirectory();
          return {
            name: entry.name,
            isDir,
            size: isDir ? 0 : fileStat.size,
            modified: fileStat.mtime.toISOString(),
            path: relativePath ? `${relativePath}/${entry.name}` : entry.name,
          };
        } catch {
          return null;
        }
      })
      .filter(Boolean)
      .sort((a, b) => {
        // Directories first, then alphabetically
        if (a!.isDir !== b!.isDir) return a!.isDir ? -1 : 1;
        return a!.name.localeCompare(b!.name);
      });

    // Get parent path
    const pathParts = relativePath.split('/').filter(Boolean);
    const parentPath = pathParts.length > 0
      ? pathParts.slice(0, -1).join('/')
      : '';

    return NextResponse.json({
      files,
      currentPath: relativePath,
      parentPath,
      totalFiles: files.length,
      totalSize: files.reduce((sum, f) => sum + (f ? f.size : 0), 0),
    });
  } catch (error: any) {
    return NextResponse.json({ error: 'Failed to browse files' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });
    }

    const body = await request.json();
    const { action, relativePath, name, content, items } = body;

    const userBase = getUserBaseDir(user.id);

    if (action === 'mkdir') {
      const dirPath = relativePath
        ? path.resolve(userBase, relativePath, name)
        : path.resolve(userBase, name);

      if (!dirPath.startsWith(userBase)) {
        return NextResponse.json({ error: 'Access denied' }, { status: 403 });
      }

      fs.mkdirSync(dirPath, { recursive: true });
      return NextResponse.json({ success: true, message: `Directory "${name}" created` });
    }

    if (action === 'touch') {
      const filePath = relativePath
        ? path.resolve(userBase, relativePath, name)
        : path.resolve(userBase, name);

      if (!filePath.startsWith(userBase)) {
        return NextResponse.json({ error: 'Access denied' }, { status: 403 });
      }

      fs.writeFileSync(filePath, content || '', 'utf-8');
      return NextResponse.json({ success: true, message: `File "${name}" created` });
    }

    if (action === 'delete') {
      if (!items || !Array.isArray(items)) {
        return NextResponse.json({ error: 'No items specified' }, { status: 400 });
      }

      for (const item of items) {
        const itemPath = path.resolve(userBase, item);
        if (!itemPath.startsWith(userBase)) continue;

        if (fs.existsSync(itemPath)) {
          const stat = fs.statSync(itemPath);
          if (stat.isDirectory()) {
            fs.rmSync(itemPath, { recursive: true, force: true });
          } else {
            fs.unlinkSync(itemPath);
          }
        }
      }
      return NextResponse.json({ success: true, message: `${items.length} item(s) deleted` });
    }

    if (action === 'rename') {
      const oldPath = path.resolve(userBase, relativePath);
      const newPath = path.resolve(userBase, path.dirname(relativePath), name);

      if (!oldPath.startsWith(userBase) || !newPath.startsWith(userBase)) {
        return NextResponse.json({ error: 'Access denied' }, { status: 403 });
      }

      if (fs.existsSync(oldPath)) {
        fs.renameSync(oldPath, newPath);
        return NextResponse.json({ success: true, message: `Renamed to "${name}"` });
      }
      return NextResponse.json({ error: 'File not found' }, { status: 404 });
    }

    if (action === 'move') {
      const { items: moveItems, destination } = body;
      if (!moveItems || !Array.isArray(moveItems) || moveItems.length === 0) {
        return NextResponse.json({ error: 'No items specified' }, { status: 400 });
      }
      if (!destination && destination !== '') {
        return NextResponse.json({ error: 'No destination specified' }, { status: 400 });
      }

      // Resolve destination relative to current working directory (not user base)
      // This allows ".." and "../folder" to work correctly from the current directory
      const cwd = relativePath ? path.resolve(userBase, relativePath) : userBase;
      let destDir: string;
      if (!destination) {
        destDir = userBase;
      } else if (destination.startsWith('/')) {
        // Absolute path within user base
        destDir = path.resolve(userBase, destination.substring(1));
      } else {
        // Relative path: resolve from current working directory
        destDir = path.resolve(cwd, destination);
      }

      // Security: ensure destination is within user base
      if (!destDir.startsWith(userBase + path.sep) && destDir !== userBase) {
        return NextResponse.json({ error: 'Access denied: destination outside your directory' }, { status: 403 });
      }

      if (!fs.existsSync(destDir)) {
        fs.mkdirSync(destDir, { recursive: true });
      }

      let movedCount = 0;
      for (const itemPath of moveItems) {
        const srcPath = path.resolve(userBase, itemPath);
        if (!srcPath.startsWith(userBase)) continue;

        // Don't move into itself
        if (destDir.startsWith(srcPath)) continue;

        const fileName = path.basename(srcPath);
        const destPath = path.join(destDir, fileName);

        if (fs.existsSync(srcPath)) {
          // Avoid overwriting existing file
          if (fs.existsSync(destPath)) {
            const ext = path.extname(fileName);
            const base = path.basename(fileName, ext);
            let counter = 1;
            let uniqueDest = path.join(destDir, `${base}_${counter}${ext}`);
            while (fs.existsSync(uniqueDest)) {
              counter++;
              uniqueDest = path.join(destDir, `${base}_${counter}${ext}`);
            }
            fs.renameSync(srcPath, uniqueDest);
          } else {
            fs.renameSync(srcPath, destPath);
          }
          movedCount++;
        }
      }

      return NextResponse.json({ success: true, message: `${movedCount} item(s) moved to ${destination || 'root'}` });
    }

    return NextResponse.json({ error: 'Invalid action' }, { status: 400 });
  } catch (error: any) {
    return NextResponse.json({ error: 'Operation failed' }, { status: 500 });
  }
}
