import { NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { stopBot } from '@/lib/deploy';

export async function POST() {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });
    }

    const result = stopBot(user.id);

    return NextResponse.json(result);
  } catch (error: any) {
    return NextResponse.json({ error: 'Stop failed' }, { status: 500 });
  }
}
