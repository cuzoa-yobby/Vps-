import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { deployBot, detectEntryPoint, listFiles } from '@/lib/deploy';

export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });
    }

    const { extractDir, entryPoint } = await request.json();

    if (!extractDir) {
      return NextResponse.json({ error: 'Extract directory is required. Upload and extract a ZIP file first.' }, { status: 400 });
    }

    const detectedEntry = entryPoint || detectEntryPoint(extractDir);

    if (!detectedEntry) {
      return NextResponse.json({
        error: 'No entry point found',
        hint: 'Expected: bot.js, main.js, index.js, server.js, app.js, bot.py, main.py, app.py',
        availableFiles: listFiles(extractDir),
      }, { status: 400 });
    }

    const result = deployBot(user.id, extractDir, detectedEntry);

    if (!result.success) {
      return NextResponse.json({ error: result.message }, { status: 500 });
    }

    return NextResponse.json({ success: true, ...result });
  } catch (error: any) {
    return NextResponse.json({ error: 'Deployment failed' }, { status: 500 });
  }
}
