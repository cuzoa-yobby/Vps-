import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { getLogs } from '@/lib/deploy';

export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });
    }

    const since = request.nextUrl.searchParams.get('since');
    const logs = getLogs(user.id, since ? parseInt(since) : undefined);

    return NextResponse.json({ logs });
  } catch (error: any) {
    return NextResponse.json({ error: 'Failed to get logs' }, { status: 500 });
  }
}
