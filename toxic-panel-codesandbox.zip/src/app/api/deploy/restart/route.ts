import { NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { restartBot } from '@/lib/deploy';

export async function POST() {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });
    }

    const result = restartBot(user.id);

    return NextResponse.json(result);
  } catch (error: any) {
    return NextResponse.json({ error: 'Restart failed' }, { status: 500 });
  }
}
