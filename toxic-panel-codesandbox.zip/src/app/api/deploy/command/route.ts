import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { sendCommand } from '@/lib/deploy';

export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });
    }

    const { command } = await request.json();

    if (!command) {
      return NextResponse.json({ error: 'Command is required' }, { status: 400 });
    }

    const result = sendCommand(user.id, command);

    return NextResponse.json(result);
  } catch (error: any) {
    return NextResponse.json({ error: 'Failed to send command' }, { status: 500 });
  }
}
