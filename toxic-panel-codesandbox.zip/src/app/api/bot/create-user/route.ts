import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { hashPassword } from '@/lib/auth';
import crypto from 'crypto';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { telegramChatId, plan } = body;

    if (!telegramChatId || !plan) {
      return NextResponse.json({ error: 'telegramChatId and plan are required' }, { status: 400 });
    }

    // Check if user already exists with this telegram chat ID
    const existingUser = await db.user.findFirst({
      where: { telegramChatId },
    });

    if (existingUser) {
      return NextResponse.json({
        success: true,
        username: existingUser.username,
        message: 'User already exists',
        loginUrl: '/',
      });
    }

    // Generate random username and password
    const randomSuffix = crypto.randomBytes(4).toString('hex');
    const username = `toxic_${randomSuffix}`;
    const password = crypto.randomBytes(6).toString('hex'); // 12 chars, but let's make 8
    const password8 = password.substring(0, 8);

    const hashedPassword = await hashPassword(password8);

    const now = new Date();
    const expiresAt = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000); // 30 days

    const user = await db.user.create({
      data: {
        username,
        password: hashedPassword,
        telegramChatId,
        plan: plan || 'free',
        status: 'active',
        activatedAt: now,
        expiresAt,
      },
    });

    return NextResponse.json({
      success: true,
      username: user.username,
      password: password8,
      loginUrl: '/',
    });
  } catch (error: any) {
    return NextResponse.json({ error: 'Failed to create user' }, { status: 500 });
  }
}
