import { NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { getServerStatus } from '@/lib/deploy';

export async function GET() {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });
    }

    const status = getServerStatus();

    return NextResponse.json(status);
  } catch (error: any) {
    return NextResponse.json({ error: 'Failed to get server status' }, { status: 500 });
  }
}
