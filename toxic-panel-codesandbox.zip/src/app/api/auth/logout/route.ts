import { NextResponse } from 'next/server';
import { clearSession } from '@/lib/auth';

export async function POST() {
  const sessionCookie = clearSession();

  return NextResponse.json({ success: true }, {
    headers: {
      'Set-Cookie': `${sessionCookie.name}=${sessionCookie.value}; HttpOnly; Path=${sessionCookie.path}; Max-Age=${sessionCookie.maxAge}; SameSite=${sessionCookie.sameSite}`,
    },
  });
}
