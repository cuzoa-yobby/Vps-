import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyPassword, setSession, getCurrentUser } from '@/lib/auth';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { username, password } = body;

    if (!username || !password) {
      return NextResponse.json({ error: 'Username and password are required' }, { status: 400 });
    }

    const user = await db.user.findUnique({
      where: { username },
    });

    if (!user) {
      return NextResponse.json({ error: 'Invalid username or password' }, { status: 401 });
    }

    const valid = await verifyPassword(password, user.password);
    if (!valid) {
      return NextResponse.json({ error: 'Invalid username or password' }, { status: 401 });
    }

    if (user.status !== 'active') {
      return NextResponse.json({ error: 'Account is not active' }, { status: 403 });
    }

    const sessionCookie = setSession(user.id);

    return NextResponse.json({
      user: {
        id: user.id,
        username: user.username,
        plan: user.plan,
        status: user.status,
        activatedAt: user.activatedAt,
        expiresAt: user.expiresAt,
      },
    }, {
      headers: {
        'Set-Cookie': `${sessionCookie.name}=${sessionCookie.value}; HttpOnly; Path=${sessionCookie.path}; Max-Age=${sessionCookie.maxAge}; SameSite=${sessionCookie.sameSite}`,
      },
    });
  } catch (error: any) {
    return NextResponse.json({ error: 'Login failed' }, { status: 500 });
  }
}
