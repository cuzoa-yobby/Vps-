// ============================================================
// Toxic Panel — Database Seeding
// Creates the admin user on first deploy
// Run: node seed.js
// ============================================================

const bcrypt = require('bcryptjs');
const { PrismaClient } = require('@prisma/client');

const DATABASE_URL = process.env.DATABASE_URL || 'file:./db/toxic.db';

const prisma = new PrismaClient({
  datasources: {
    db: {
      url: DATABASE_URL,
    },
  },
});

async function seed() {
  console.log('Seeding database...');

  // Ensure db directory exists
  const fs = require('fs');
  if (!fs.existsSync('db')) {
    fs.mkdirSync('db', { recursive: true });
  }

  // Check if admin exists
  const existingAdmin = await prisma.user.findUnique({
    where: { username: 'toxic_admin' },
  });

  if (existingAdmin) {
    console.log('Admin user already exists, skipping...');
    console.log('  Username: toxic_admin');
    console.log('  Password: (unchanged)');
  } else {
    const hashedPassword = await bcrypt.hash('ToxicAdmin@2024', 10);
    await prisma.user.create({
      data: {
        username: 'toxic_admin',
        password: hashedPassword,
        plan: 'admin',
        status: 'active',
        activatedAt: new Date(),
        expiresAt: new Date('2099-12-31'),
      },
    });
    console.log('Admin user created!');
    console.log('  Username: toxic_admin');
    console.log('  Password: ToxicAdmin@2024');
  }

  console.log('Done!');
}

seed()
  .catch(console.error)
  .finally(() => prisma.$disconnect());
